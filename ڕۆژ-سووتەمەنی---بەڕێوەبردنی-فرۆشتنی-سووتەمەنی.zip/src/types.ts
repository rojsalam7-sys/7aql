export type UserRole = 'admin' | 'driver';

export type FuelType = 'diesel' | 'gas';

export interface Account {
  id: number;
  name: string;
  code: string;
  role: UserRole;
  phone: string;
  truckPlate: string;
  active: boolean;
  createdAt: string;
}

export interface DriverSummary extends Account {
  entryCount: number;
  totalLiters: number;
  totalCost: number;
  monthLiters: number;
  monthCost: number;
  lastEntryDate: string | null;
}

export interface FuelEntry {
  id: number;
  driverId: number;
  driverName: string;
  driverCode: string;
  driverTruckPlate: string;
  fuelType: FuelType;
  liters: number;
  pricePerLiter: number;
  totalPrice: number;
  entryDate: string;
  note: string;
  createdAt: string;
}

export interface MonthlyReportDriverRow {
  driverId: number;
  driverName: string;
  driverCode: string;
  truckPlate: string;
  phone: string;
  entryCount: number;
  dieselLiters: number;
  gasLiters: number;
  totalLiters: number;
  totalCost: number;
}

export interface MonthlyReportResponse {
  month: string;
  summary: {
    totalLiters: number;
    totalCost: number;
    dieselLiters: number;
    gasLiters: number;
    entryCount: number;
    driverCount: number;
  };
  drivers: MonthlyReportDriverRow[];
  availableMonths: string[];
}

export interface DriverStatementResponse {
  driver: Account;
  month: string;
  summary: {
    totalLiters: number;
    totalCost: number;
    dieselLiters: number;
    gasLiters: number;
    entryCount: number;
  };
  lifetime: {
    totalLiters: number;
    totalCost: number;
    entryCount: number;
  };
  entries: FuelEntry[];
  availableMonths: string[];
}
