import { useCallback, useEffect, useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { BrandMark } from './components/BrandMark';
import { DriverDashboard } from './components/DriverDashboard';
import { LoginView } from './components/LoginView';
import { apiRequest, getStoredToken, setStoredToken } from './lib/api';
import type { Account } from './types';

export default function App() {
  const [user, setUser] = useState<Account | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  const handleLogout = useCallback(() => {
    setStoredToken(null);
    setUser(null);
  }, []);

  useEffect(() => {
    const token = getStoredToken();
    if (!token) {
      setCheckingSession(false);
      return;
    }

    let active = true;
    apiRequest<{ user: Account }>('/api/auth/me')
      .then((res) => {
        if (active) setUser(res.user);
      })
      .catch(() => {
        if (active) {
          setStoredToken(null);
          setUser(null);
        }
      })
      .finally(() => {
        if (active) setCheckingSession(false);
      });

    return () => {
      active = false;
    };
  }, []);

  function handleLoginSuccess(token: string, loggedUser: Account) {
    setStoredToken(token);
    setUser(loggedUser);
  }

  if (checkingSession) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-3">
        <BrandMark className="w-12 h-12 animate-pulse" />
        <p className="text-sm font-medium text-slate-600">چاوەڕوانبە...</p>
      </div>
    );
  }

  if (!user) {
    return <LoginView onLoginSuccess={handleLoginSuccess} />;
  }

  if (user.role === 'admin') {
    return <AdminDashboard user={user} onLogout={handleLogout} />;
  }

  return <DriverDashboard user={user} onLogout={handleLogout} />;
}
