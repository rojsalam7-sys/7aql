import type { FuelEntry, MonthlyReportDriverRow } from '../types';

const KURDISH_MONTHS: Record<string, string> = {
  '01': 'کانوونی دووەم',
  '02': 'شوبات',
  '03': 'ئازار',
  '04': 'نیسان',
  '05': 'ئایار',
  '06': 'حوزەیران',
  '07': 'تەممووز',
  '08': 'ئاب',
  '09': 'ئەیلوول',
  '10': 'تشرینی یەکەم',
  '11': 'تشرینی دووەم',
  '12': 'کانوونی یەکەم',
};

export function getTodayDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentMonth(): string {
  return getTodayDate().slice(0, 7);
}

export function formatNumber(value: number, maxFractionDigits = 0): string {
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: maxFractionDigits,
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatIQD(amount: number): string {
  return `${formatNumber(Math.round(amount))} دینار`;
}

export function formatLiters(liters: number): string {
  const hasDecimals = Math.abs(liters % 1) > 0.001;
  return `${formatNumber(liters, hasDecimals ? 2 : 0)} لیتر`;
}

export function formatMonthLabel(ym: string): string {
  if (ym === 'all') return 'هەموو مانگەکان';
  const [year, month] = ym.split('-');
  const name = KURDISH_MONTHS[month] ?? month;
  return `${name} ${year} (${ym})`;
}

export function formatFuelType(type: 'diesel' | 'gas'): string {
  return type === 'diesel' ? 'گازوایل' : 'بەنزین';
}

function escapeCsvCell(value: string | number): string {
  const text = String(value ?? '');
  if (text.includes(',') || text.includes('"') || text.includes('\n')) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function triggerCsvDownload(filename: string, headers: string[], rows: Array<Array<string | number>>) {
  const csvContent =
    '\uFEFF' +
    [headers.map(escapeCsvCell).join(','), ...rows.map((r) => r.map(escapeCsvCell).join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportMonthlyReportCsv(month: string, rows: MonthlyReportDriverRow[]) {
  const headers = [
    'ناوی شۆفێر',
    'کۆد',
    'تابلۆی بارهەڵگر',
    'ژمارەی مۆبایل',
    'ژمارەی پسوڵە',
    'گازوایل (لیتر)',
    'بەنزین (لیتر)',
    'کۆی لیتر',
    'کۆی گشتی (IQD)',
  ];
  const dataRows = rows.map((r) => [
    r.driverName,
    r.driverCode,
    r.truckPlate || '-',
    r.phone || '-',
    r.entryCount,
    r.dieselLiters,
    r.gasLiters,
    r.totalLiters,
    Math.round(r.totalCost),
  ]);
  triggerCsvDownload(`roj-fuel-monthly-report-${month}.csv`, headers, dataRows);
}

export function exportDriverStatementCsv(driverName: string, month: string, entries: FuelEntry[]) {
  const headers = ['بەروار', 'ناوی شۆفێر', 'کۆد', 'جۆری سووتەمەنی', 'لیتر', 'نرخی یەک لیتر (IQD)', 'کۆی نرخ (IQD)', 'تێبینی'];
  const dataRows = entries.map((e) => [
    e.entryDate,
    e.driverName,
    e.driverCode,
    formatFuelType(e.fuelType),
    e.liters,
    Math.round(e.pricePerLiter),
    Math.round(e.totalPrice),
    e.note || '-',
  ]);
  const safeName = driverName.replace(/\s+/g, '-');
  triggerCsvDownload(`roj-fuel-statement-${safeName}-${month}.csv`, headers, dataRows);
}
