import { useEffect, useState, type FormEvent } from 'react';
import { X } from 'lucide-react';
import { apiRequest, ApiError } from '../lib/api';
import { formatIQD } from '../lib/format';
import type { DriverSummary, FuelEntry, FuelType } from '../types';

interface FuelEntryEditModalProps {
  open: boolean;
  entry: FuelEntry | null;
  drivers: DriverSummary[];
  onClose: () => void;
  onSaved: () => void;
}

export function FuelEntryEditModal({
  open,
  entry,
  drivers,
  onClose,
  onSaved,
}: FuelEntryEditModalProps) {
  const [driverId, setDriverId] = useState<number>(0);
  const [fuelType, setFuelType] = useState<FuelType>('diesel');
  const [liters, setLiters] = useState('');
  const [pricePerLiter, setPricePerLiter] = useState('');
  const [totalPrice, setTotalPrice] = useState('');
  const [entryDate, setEntryDate] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !entry) return;
    setError(null);
    setDriverId(entry.driverId);
    setFuelType(entry.fuelType);
    setLiters(String(entry.liters));
    setPricePerLiter(String(entry.pricePerLiter));
    setTotalPrice(String(entry.totalPrice));
    setEntryDate(entry.entryDate);
    setNote(entry.note);
  }, [open, entry]);

  if (!open || !entry) return null;

  function handleLitersOrPriceChange(nextLiters: string, nextPrice: string) {
    setLiters(nextLiters);
    setPricePerLiter(nextPrice);
    const l = Number(nextLiters);
    const p = Number(nextPrice);
    if (Number.isFinite(l) && Number.isFinite(p) && l > 0 && p >= 0) {
      setTotalPrice(String(Math.round(l * p)));
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!entry) return;
    setError(null);

    const l = Number(liters);
    const p = Number(pricePerLiter || 0);
    const t = Number(totalPrice);

    if (!Number.isFinite(l) || l <= 0) {
      setError('تکایە بڕی لیتر بە دروستی بنووسە.');
      return;
    }
    if (!Number.isFinite(t) || t < 0) {
      setError('تکایە کۆی نرخ بە دروستی بنووسە.');
      return;
    }

    setSaving(true);
    try {
      await apiRequest(`/api/fuel-entries/${entry.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          driverId,
          fuelType,
          liters: l,
          pricePerLiter: p,
          totalPrice: Math.round(t),
          entryDate,
          note: note.trim(),
        }),
      });
      onSaved();
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'هەڵە لە نوێکردنەوە.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full sm:max-w-lg bg-white border border-slate-200 rounded-t-2xl sm:rounded-2xl shadow-xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">دەستکاریکردنی تۆماری سووتەمەنی</h3>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            aria-label="داخستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label htmlFor="edit-driver" className="block text-sm font-semibold text-slate-800 mb-1.5">
              شۆفێر
            </label>
            <select
              id="edit-driver"
              value={driverId}
              onChange={(e) => setDriverId(Number(e.target.value))}
              className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
            >
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.code})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setFuelType('diesel')}
              className={`min-h-[40px] rounded-lg text-sm font-semibold transition-colors ${
                fuelType === 'diesel' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              گازوایل (Diesel)
            </button>
            <button
              type="button"
              onClick={() => setFuelType('gas')}
              className={`min-h-[40px] rounded-lg text-sm font-semibold transition-colors ${
                fuelType === 'gas' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              بەنزین (Gas)
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="edit-liters" className="block text-sm font-semibold text-slate-800 mb-1.5">
                بڕی لیتر
              </label>
              <input
                id="edit-liters"
                type="number"
                step="any"
                min="0.1"
                value={liters}
                onChange={(e) => handleLitersOrPriceChange(e.target.value, pricePerLiter)}
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
            </div>

            <div>
              <label htmlFor="edit-price-liter" className="block text-sm font-semibold text-slate-800 mb-1.5">
                نرخی یەک لیتر (دینار)
              </label>
              <input
                id="edit-price-liter"
                type="number"
                step="any"
                min="0"
                value={pricePerLiter}
                onChange={(e) => handleLitersOrPriceChange(liters, e.target.value)}
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="edit-total" className="block text-sm font-semibold text-slate-800 mb-1.5">
                کۆی نرخ (دینار)
              </label>
              <input
                id="edit-total"
                type="number"
                step="any"
                min="0"
                value={totalPrice}
                onChange={(e) => setTotalPrice(e.target.value)}
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
              <div className="mt-1 text-xs text-slate-500 tabular-nums">
                {formatIQD(Number(totalPrice || 0))}
              </div>
            </div>

            <div>
              <label htmlFor="edit-date" className="block text-sm font-semibold text-slate-800 mb-1.5">
                بەروار
              </label>
              <input
                id="edit-date"
                type="date"
                value={entryDate}
                onChange={(e) => setEntryDate(e.target.value)}
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
            </div>
          </div>

          <div>
            <label htmlFor="edit-note" className="block text-sm font-semibold text-slate-800 mb-1.5">
              تێبینی
            </label>
            <input
              id="edit-note"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="تێبینی..."
              className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="min-h-[46px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
            >
              پاشگەزبوونەوە
            </button>
            <button
              type="submit"
              disabled={saving}
              className="min-h-[46px] px-6 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl disabled:opacity-60"
            >
              {saving ? 'پاشەکەوت دەکرێت...' : 'نوێکردنەوە'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
