import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import {
  CheckCircle2,
  Download,
  Edit3,
  FileText,
  Fuel,
  History,
  LogOut,
  Plus,
  Printer,
  Search,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { apiRequest, ApiError } from '../lib/api';
import {
  exportMonthlyReportCsv,
  formatFuelType,
  formatIQD,
  formatLiters,
  formatMonthLabel,
  getCurrentMonth,
  getTodayDate,
} from '../lib/format';
import type {
  Account,
  DriverSummary,
  FuelEntry,
  FuelType,
  MonthlyReportResponse,
} from '../types';
import { BrandMark } from './BrandMark';
import { ConfirmModal } from './ConfirmModal';
import { DriverFormModal } from './DriverFormModal';
import { DriverStatementModal } from './DriverStatementModal';
import { FuelEntryEditModal } from './FuelEntryEditModal';

type AdminTab = 'entry' | 'drivers' | 'ledger' | 'reports';

const LAST_PRICE_KEY = 'roj_fuel_last_prices_iqd';

function getSavedPrice(fuelType: FuelType): string {
  try {
    const raw = localStorage.getItem(LAST_PRICE_KEY);
    if (!raw) return fuelType === 'diesel' ? '750' : '850';
    const parsed = JSON.parse(raw) as Partial<Record<FuelType, string>>;
    return parsed[fuelType] ?? (fuelType === 'diesel' ? '750' : '850');
  } catch {
    return fuelType === 'diesel' ? '750' : '850';
  }
}

function savePrice(fuelType: FuelType, value: string) {
  try {
    const raw = localStorage.getItem(LAST_PRICE_KEY);
    const parsed = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    parsed[fuelType] = value;
    localStorage.setItem(LAST_PRICE_KEY, JSON.stringify(parsed));
  } catch {
    // Ignore
  }
}

interface AdminDashboardProps {
  user: Account;
  onLogout: () => void;
}

export function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const [tab, setTab] = useState<AdminTab>('entry');

  // Core data
  const [drivers, setDrivers] = useState<DriverSummary[]>([]);
  const [recentEntries, setRecentEntries] = useState<FuelEntry[]>([]);
  const [ledgerEntries, setLedgerEntries] = useState<FuelEntry[]>([]);
  const [monthlyReport, setMonthlyReport] = useState<MonthlyReportResponse | null>(null);

  const [loadingDrivers, setLoadingDrivers] = useState(true);
  const [loadingLedger, setLoadingLedger] = useState(false);
  const [loadingReport, setLoadingReport] = useState(false);

  // Filters
  const [driverSearch, setDriverSearch] = useState('');
  const [ledgerMonth, setLedgerMonth] = useState<string>(getCurrentMonth());
  const [ledgerFuelFilter, setLedgerFuelFilter] = useState<'all' | FuelType>('all');
  const [ledgerSearch, setLedgerSearch] = useState('');
  const [reportMonth, setReportMonth] = useState<string>(getCurrentMonth());
  const [reportSearch, setReportSearch] = useState('');

  // Fuel Entry Form State
  const [selectedDriverId, setSelectedDriverId] = useState<number | null>(null);
  const [driverPickerQuery, setDriverPickerQuery] = useState('');
  const [driverPickerOpen, setDriverPickerOpen] = useState(false);
  const driverPickerRef = useRef<HTMLDivElement>(null);

  const [fuelType, setFuelType] = useState<FuelType>('diesel');
  const [liters, setLiters] = useState('');
  const [pricePerLiter, setPricePerLiter] = useState(() => getSavedPrice('diesel'));
  const [totalPrice, setTotalPrice] = useState('');
  const [totalManuallyEdited, setTotalManuallyEdited] = useState(false);
  const [entryDate, setEntryDate] = useState(() => getTodayDate());
  const [note, setNote] = useState('');
  const [entrySubmitting, setEntrySubmitting] = useState(false);
  const [entryError, setEntryError] = useState<string | null>(null);
  const [entrySuccess, setEntrySuccess] = useState<string | null>(null);

  // Modals
  const [driverModalOpen, setDriverModalOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState<DriverSummary | null>(null);
  const [deletingDriver, setDeletingDriver] = useState<DriverSummary | null>(null);
  const [deletingEntry, setDeletingEntry] = useState<FuelEntry | null>(null);
  const [editingEntry, setEditingEntry] = useState<FuelEntry | null>(null);
  const [statementDriverId, setStatementDriverId] = useState<number | null>(null);
  const [statementInitialMonth, setStatementInitialMonth] = useState<string | undefined>(undefined);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const handleApiError = useCallback(
    (err: unknown) => {
      if (err instanceof ApiError && err.status === 401) {
        onLogout();
      }
    },
    [onLogout]
  );

  const loadDrivers = useCallback(async () => {
    setLoadingDrivers(true);
    try {
      const res = await apiRequest<{ drivers: DriverSummary[] }>(
        `/api/drivers?month=${encodeURIComponent(getCurrentMonth())}`
      );
      setDrivers(res.drivers);
    } catch (err) {
      handleApiError(err);
    } finally {
      setLoadingDrivers(false);
    }
  }, [handleApiError]);

  const loadRecentEntries = useCallback(async () => {
    try {
      const res = await apiRequest<{ entries: FuelEntry[] }>('/api/fuel-entries?limit=25');
      setRecentEntries(res.entries);
    } catch (err) {
      handleApiError(err);
    }
  }, [handleApiError]);

  const loadLedger = useCallback(async () => {
    setLoadingLedger(true);
    try {
      const params = new URLSearchParams();
      if (ledgerMonth !== 'all') params.set('month', ledgerMonth);
      if (ledgerFuelFilter !== 'all') params.set('fuelType', ledgerFuelFilter);
      if (ledgerSearch.trim()) params.set('search', ledgerSearch.trim());
      params.set('limit', '500');
      const res = await apiRequest<{ entries: FuelEntry[] }>(
        `/api/fuel-entries?${params.toString()}`
      );
      setLedgerEntries(res.entries);
    } catch (err) {
      handleApiError(err);
    } finally {
      setLoadingLedger(false);
    }
  }, [ledgerMonth, ledgerFuelFilter, ledgerSearch, handleApiError]);

  const loadMonthlyReport = useCallback(async () => {
    setLoadingReport(true);
    try {
      const res = await apiRequest<MonthlyReportResponse>(
        `/api/reports/monthly?month=${encodeURIComponent(reportMonth)}`
      );
      setMonthlyReport(res);
    } catch (err) {
      handleApiError(err);
    } finally {
      setLoadingReport(false);
    }
  }, [reportMonth, handleApiError]);

  useEffect(() => {
    loadDrivers();
    loadRecentEntries();
  }, [loadDrivers, loadRecentEntries]);

  useEffect(() => {
    if (tab === 'ledger') {
      loadLedger();
    } else if (tab === 'reports') {
      loadMonthlyReport();
    }
  }, [tab, loadLedger, loadMonthlyReport]);

  // Close driver picker dropdown on outside click
  useEffect(() => {
    function handleOutsideClick(event: MouseEvent) {
      if (
        driverPickerRef.current &&
        !driverPickerRef.current.contains(event.target as Node)
      ) {
        setDriverPickerOpen(false);
      }
    }
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const activeDrivers = useMemo(
    () => drivers.filter((d) => d.active),
    [drivers]
  );

  const selectedDriver = useMemo(
    () => drivers.find((d) => d.id === selectedDriverId) ?? null,
    [drivers, selectedDriverId]
  );

  const pickerMatches = useMemo(() => {
    const q = driverPickerQuery.trim().toLowerCase();
    const list = activeDrivers;
    if (!q) return list.slice(0, 30);
    return list
      .filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.code.toLowerCase().includes(q) ||
          d.truckPlate.toLowerCase().includes(q)
      )
      .slice(0, 30);
  }, [activeDrivers, driverPickerQuery]);

  const filteredDrivers = useMemo(() => {
    const q = driverSearch.trim().toLowerCase();
    if (!q) return drivers;
    return drivers.filter(
      (d) =>
        d.name.toLowerCase().includes(q) ||
        d.code.toLowerCase().includes(q) ||
        d.truckPlate.toLowerCase().includes(q) ||
        d.phone.toLowerCase().includes(q)
    );
  }, [drivers, driverSearch]);

  const filteredReportDrivers = useMemo(() => {
    const list = monthlyReport?.drivers ?? [];
    const q = reportSearch.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (r) =>
        r.driverName.toLowerCase().includes(q) ||
        r.driverCode.toLowerCase().includes(q) ||
        r.truckPlate.toLowerCase().includes(q)
    );
  }, [monthlyReport, reportSearch]);

  const availableMonths = useMemo(() => {
    const set = new Set<string>([
      getCurrentMonth(),
      ...(monthlyReport?.availableMonths ?? []),
    ]);
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [monthlyReport]);

  function handleFuelTypeSwitch(nextType: FuelType) {
    setFuelType(nextType);
    const saved = getSavedPrice(nextType);
    setPricePerLiter(saved);
    if (!totalManuallyEdited) {
      const l = Number(liters);
      const p = Number(saved);
      if (Number.isFinite(l) && l > 0 && Number.isFinite(p) && p >= 0) {
        setTotalPrice(String(Math.round(l * p)));
      }
    }
  }

  function handleLitersChange(val: string) {
    setLiters(val);
    if (!totalManuallyEdited) {
      const l = Number(val);
      const p = Number(pricePerLiter);
      if (Number.isFinite(l) && l > 0 && Number.isFinite(p) && p >= 0) {
        setTotalPrice(String(Math.round(l * p)));
      } else {
        setTotalPrice('');
      }
    }
  }

  function handlePricePerLiterChange(val: string) {
    setPricePerLiter(val);
    setTotalManuallyEdited(false);
    const l = Number(liters);
    const p = Number(val);
    if (Number.isFinite(l) && l > 0 && Number.isFinite(p) && p >= 0) {
      setTotalPrice(String(Math.round(l * p)));
    }
  }

  function handleSelectDriverForEntry(driver: DriverSummary) {
    setSelectedDriverId(driver.id);
    setDriverPickerQuery(`${driver.name} (${driver.code})`);
    setDriverPickerOpen(false);
    setEntryError(null);
  }

  async function handleFuelEntrySubmit(e: FormEvent) {
    e.preventDefault();
    setEntryError(null);
    setEntrySuccess(null);

    if (!selectedDriverId) {
      setEntryError('تکایە سەرەتا شۆفێرێک هەڵبژێرە.');
      return;
    }

    const l = Number(liters);
    const p = Number(pricePerLiter || 0);
    const t = totalPrice !== '' ? Number(totalPrice) : Math.round(l * p);

    if (!Number.isFinite(l) || l <= 0) {
      setEntryError('تکایە بڕی لیتر بە دروستی بنووسە.');
      return;
    }
    if (!Number.isFinite(t) || t < 0) {
      setEntryError('تکایە نرخ بە دروستی بنووسە بە دیناری عێراقی.');
      return;
    }

    setEntrySubmitting(true);
    try {
      if (pricePerLiter.trim()) {
        savePrice(fuelType, pricePerLiter.trim());
      }
      const res = await apiRequest<{ entry: FuelEntry }>('/api/fuel-entries', {
        method: 'POST',
        body: JSON.stringify({
          driverId: selectedDriverId,
          fuelType,
          liters: l,
          pricePerLiter: p,
          totalPrice: Math.round(t),
          entryDate,
          note: note.trim(),
        }),
      });

      setEntrySuccess(
        `تۆمارکرا: ${res.entry.driverName} · ${formatLiters(res.entry.liters)} · ${formatIQD(res.entry.totalPrice)}`
      );
      setLiters('');
      setTotalPrice('');
      setTotalManuallyEdited(false);
      setNote('');
      setSelectedDriverId(null);
      setDriverPickerQuery('');

      await Promise.all([loadRecentEntries(), loadDrivers()]);
    } catch (err) {
      setEntryError(err instanceof ApiError ? err.message : 'هەڵە لە تۆمارکردن.');
    } finally {
      setEntrySubmitting(false);
    }
  }

  async function confirmDeleteDriver() {
    if (!deletingDriver) return;
    setConfirmBusy(true);
    try {
      await apiRequest(`/api/drivers/${deletingDriver.id}`, { method: 'DELETE' });
      setDeletingDriver(null);
      await Promise.all([loadDrivers(), loadRecentEntries()]);
      if (tab === 'ledger') await loadLedger();
      if (tab === 'reports') await loadMonthlyReport();
    } catch (err) {
      handleApiError(err);
    } finally {
      setConfirmBusy(false);
    }
  }

  async function confirmDeleteEntry() {
    if (!deletingEntry) return;
    setConfirmBusy(true);
    try {
      await apiRequest(`/api/fuel-entries/${deletingEntry.id}`, { method: 'DELETE' });
      setDeletingEntry(null);
      await Promise.all([loadRecentEntries(), loadDrivers()]);
      if (tab === 'ledger') await loadLedger();
      if (tab === 'reports') await loadMonthlyReport();
    } catch (err) {
      handleApiError(err);
    } finally {
      setConfirmBusy(false);
    }
  }

  const navItems: Array<{ id: AdminTab; label: string; shortLabel: string; icon: typeof Fuel }> = [
    { id: 'entry', label: 'تۆمارکردنی سووتەمەنی', shortLabel: 'فرۆشتن', icon: Fuel },
    { id: 'drivers', label: 'بەڕێوەبردنی شۆفێران', shortLabel: 'شۆفێران', icon: Users },
    { id: 'ledger', label: 'هەموو تۆمارەکان', shortLabel: 'تۆمارەکان', icon: History },
    { id: 'reports', label: 'ڕاپۆرتی مانگانە', shortLabel: 'ڕاپۆرت', icon: FileText },
  ];

  const activeNavTitle = navItems.find((n) => n.id === tab)?.label ?? '';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar (RTL Right) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-white border-l border-slate-200 sticky top-0 h-screen no-print">
        <div className="h-16 px-5 border-b border-slate-200 flex items-center gap-3">
          <BrandMark className="w-8 h-8 shrink-0" />
          <span className="font-bold text-slate-900 text-base whitespace-nowrap">
            ڕۆژ سووتەمەنی
          </span>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-3 transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 space-y-3">
          <div className="px-2">
            <div className="text-sm font-bold text-slate-900 truncate">{user.name}</div>
            <div className="text-xs text-slate-500 font-mono-num">
              بەڕێوەبەر · کۆد: {user.code}
            </div>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="w-full min-h-[42px] px-3.5 py-2 rounded-xl text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>دەرچوون</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar (Desktop & Mobile) */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 no-print">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="lg:hidden">
                <BrandMark className="w-7 h-7 shrink-0" />
              </div>
              <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {activeNavTitle}
              </h1>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {tab === 'drivers' && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingDriver(null);
                    setDriverModalOpen(true);
                  }}
                  className="min-h-[40px] px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  <span>شۆفێری نوێ</span>
                </button>
              )}

              <button
                type="button"
                onClick={onLogout}
                className="lg:hidden min-h-[40px] min-w-[40px] px-2.5 py-2 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-xl flex items-center gap-1 whitespace-nowrap"
                aria-label="دەرچوون"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">دەرچوون</span>
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-7 pb-24 lg:pb-10">
          {/* TAB 1: ADD FUEL ENTRY */}
          {tab === 'entry' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Entry Form */}
              <section className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-lg font-bold text-slate-900">تۆماری فرۆشتنی نوێ</h2>
                  <span className="text-xs text-slate-500">دیناری عێراقی (IQD)</span>
                </div>

                {entryError && (
                  <div className="mb-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
                    {entryError}
                  </div>
                )}

                {entrySuccess && (
                  <div className="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>{entrySuccess}</span>
                  </div>
                )}

                <form onSubmit={handleFuelEntrySubmit} className="space-y-4">
                  {/* Driver Searchable Picker */}
                  <div ref={driverPickerRef} className="relative">
                    <label
                      htmlFor="fuel-driver-search"
                      className="block text-sm font-semibold text-slate-800 mb-1.5"
                    >
                      هەڵبژاردنی شۆفێر (بە ناو یان کۆد) *
                    </label>
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="fuel-driver-search"
                        type="text"
                        value={driverPickerQuery}
                        onFocus={() => setDriverPickerOpen(true)}
                        onChange={(e) => {
                          setDriverPickerQuery(e.target.value);
                          setSelectedDriverId(null);
                          setDriverPickerOpen(true);
                        }}
                        placeholder={
                          loadingDrivers
                            ? 'چاوەڕوانبە...'
                            : 'ناو یان کۆدی شۆفێر بنووسە...'
                        }
                        className="w-full min-h-[48px] pr-10 pl-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                      />
                      {driverPickerQuery && (
                        <button
                          type="button"
                          onClick={() => {
                            setDriverPickerQuery('');
                            setSelectedDriverId(null);
                            setDriverPickerOpen(true);
                          }}
                          className="min-h-[40px] min-w-[40px] flex items-center justify-center absolute left-1 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                          aria-label="پاککردنەوە"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {selectedDriver && (
                      <div className="mt-1.5 text-xs text-emerald-700 flex items-center gap-2">
                        <span>هەڵبژێردرا: {selectedDriver.name}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-num">کۆد: {selectedDriver.code}</span>
                        {selectedDriver.truckPlate && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{selectedDriver.truckPlate}</span>
                          </>
                        )}
                      </div>
                    )}

                    {driverPickerOpen && (
                      <div className="absolute z-20 mt-1.5 w-full bg-white border border-slate-200 rounded-xl shadow-lg max-h-60 overflow-y-auto divide-y divide-slate-100">
                        {activeDrivers.length === 0 ? (
                          <div className="p-4 text-center space-y-2">
                            <p className="text-xs text-slate-500">
                              هێشتا هیچ شۆفێرێکی چالاک زیاد نەکراوە.
                            </p>
                            <button
                              type="button"
                              onClick={() => {
                                setDriverPickerOpen(false);
                                setEditingDriver(null);
                                setDriverModalOpen(true);
                              }}
                              className="min-h-[40px] px-3 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-lg"
                            >
                              زیادکردنی شۆفێری نوێ
                            </button>
                          </div>
                        ) : pickerMatches.length === 0 ? (
                          <div className="p-4 text-center text-xs text-slate-500">
                            هیچ شۆفێرێک بەم ناوە یان کۆدە نەدۆزرایەوە.
                          </div>
                        ) : (
                          pickerMatches.map((d) => (
                            <button
                              key={d.id}
                              type="button"
                              onClick={() => handleSelectDriverForEntry(d)}
                              className="w-full min-h-[48px] px-4 py-2.5 text-right hover:bg-amber-50/70 transition-colors flex items-center justify-between gap-2"
                            >
                              <div className="min-w-0">
                                <div className="text-sm font-semibold text-slate-900 truncate">
                                  {d.name}
                                </div>
                                {d.truckPlate && (
                                  <div className="text-xs text-slate-500 truncate">
                                    تابلۆ: {d.truckPlate}
                                  </div>
                                )}
                              </div>
                              <span className="text-xs font-mono-num font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg shrink-0">
                                {d.code}
                              </span>
                            </button>
                          ))
                        )}
                      </div>
                    )}
                  </div>

                  {/* Fuel Type Segmented Toggle */}
                  <div>
                    <span className="block text-sm font-semibold text-slate-800 mb-1.5">
                      جۆری سووتەمەنی
                    </span>
                    <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-xl">
                      <button
                        type="button"
                        onClick={() => handleFuelTypeSwitch('diesel')}
                        className={`min-h-[44px] rounded-lg text-sm font-semibold transition-colors ${
                          fuelType === 'diesel'
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        گازوایل (Diesel)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleFuelTypeSwitch('gas')}
                        className={`min-h-[44px] rounded-lg text-sm font-semibold transition-colors ${
                          fuelType === 'gas'
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        بەنزین (Gas)
                      </button>
                    </div>
                  </div>

                  {/* Liters + Price per Liter */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="fuel-liters" className="block text-sm font-semibold text-slate-800 mb-1.5">
                        بڕی لیتر *
                      </label>
                      <input
                        id="fuel-liters"
                        type="number"
                        step="any"
                        min="0.1"
                        inputMode="decimal"
                        value={liters}
                        onChange={(e) => handleLitersChange(e.target.value)}
                        placeholder="0"
                        className="w-full min-h-[48px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-base font-bold font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                      />
                    </div>

                    <div>
                      <label htmlFor="fuel-price-liter" className="block text-sm font-semibold text-slate-800 mb-1.5">
                        نرخی لیتر (دینار)
                      </label>
                      <input
                        id="fuel-price-liter"
                        type="number"
                        step="any"
                        min="0"
                        inputMode="numeric"
                        value={pricePerLiter}
                        onChange={(e) => handlePricePerLiterChange(e.target.value)}
                        placeholder="750"
                        className="w-full min-h-[48px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-base font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                      />
                    </div>
                  </div>

                  {/* Total Price + Date */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="fuel-total" className="block text-sm font-semibold text-slate-800 mb-1.5">
                        کۆی نرخ (دینار) *
                      </label>
                      <input
                        id="fuel-total"
                        type="number"
                        step="any"
                        min="0"
                        inputMode="numeric"
                        value={totalPrice}
                        onChange={(e) => {
                          setTotalManuallyEdited(true);
                          setTotalPrice(e.target.value);
                        }}
                        placeholder="0"
                        className="w-full min-h-[48px] px-3.5 py-2 bg-amber-50/60 border border-amber-200 rounded-xl text-base font-bold font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                      />
                      <div className="mt-1 text-xs font-medium text-amber-800 tabular-nums">
                        {formatIQD(Number(totalPrice || 0))}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="fuel-date" className="block text-sm font-semibold text-slate-800 mb-1.5">
                        بەروار
                      </label>
                      <input
                        id="fuel-date"
                        type="date"
                        value={entryDate}
                        onChange={(e) => setEntryDate(e.target.value)}
                        className="w-full min-h-[48px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="fuel-note" className="block text-sm font-semibold text-slate-800 mb-1.5">
                      تێبینی (ئارەزوومەندانە)
                    </label>
                    <input
                      id="fuel-note"
                      type="text"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="ژمارەی پسوڵە یان تێبینی..."
                      className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={entrySubmitting}
                    className="w-full min-h-[50px] px-5 py-3 bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-base font-bold rounded-xl transition-all disabled:opacity-60 cursor-pointer"
                  >
                    {entrySubmitting ? 'تۆمار دەکرێت...' : 'تۆمارکردنی فرۆشتن'}
                  </button>
                </form>
              </section>

              {/* Recent Entries Panel */}
              <section className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
                  <h2 className="text-base sm:text-lg font-bold text-slate-900">
                    دوایین تۆمارەکان
                  </h2>
                  <button
                    type="button"
                    onClick={() => setTab('ledger')}
                    className="text-xs font-semibold text-amber-700 hover:text-amber-800 whitespace-nowrap"
                  >
                    بینینی هەمووی
                  </button>
                </div>

                {recentEntries.length === 0 ? (
                  <div className="p-10 text-center text-sm text-slate-500">
                    هێشتا هیچ فرۆشتنێک تۆمار نەکراوە.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {recentEntries.slice(0, 10).map((entry) => (
                      <div
                        key={entry.id}
                        className="p-4 hover:bg-slate-50/70 transition-colors flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-bold text-slate-900 truncate">
                              {entry.driverName}
                            </span>
                            <span className="text-xs font-mono-num text-slate-500">
                              ({entry.driverCode})
                            </span>
                          </div>
                          <div className="mt-1 text-xs text-slate-500 flex flex-wrap items-center gap-2">
                            <span className="font-mono-num">{entry.entryDate}</span>
                            <span aria-hidden="true">·</span>
                            <span>{formatFuelType(entry.fuelType)}</span>
                            <span aria-hidden="true">·</span>
                            <span className="font-semibold text-slate-700 tabular-nums">
                              {formatLiters(entry.liters)}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <div className="text-left">
                            <div className="text-sm font-bold text-slate-900 tabular-nums">
                              {formatIQD(entry.totalPrice)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => setEditingEntry(entry)}
                            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                            aria-label="دەستکاریکردن"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeletingEntry(entry)}
                            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50"
                            aria-label="سڕینەوە"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>
          )}

          {/* TAB 2: DRIVERS MANAGEMENT */}
          {tab === 'drivers' && (
            <div className="space-y-5">
              <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={driverSearch}
                    onChange={(e) => setDriverSearch(e.target.value)}
                    placeholder="گەڕان بە ناو، کۆد، تابلۆ یان مۆبایل..."
                    className="w-full min-h-[44px] pr-10 pl-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                  />
                </div>
                <div className="text-xs sm:text-sm text-slate-600 flex items-center gap-3">
                  <span>کۆی شۆفێران: <strong className="tabular-nums text-slate-900">{drivers.length}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>چالاک: <strong className="tabular-nums text-emerald-700">{activeDrivers.length}</strong></span>
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                {loadingDrivers ? (
                  <div className="p-6 space-y-3">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-12 bg-slate-100 rounded-xl animate-pulse" />
                    ))}
                  </div>
                ) : filteredDrivers.length === 0 ? (
                  <div className="p-12 text-center space-y-3">
                    <p className="text-sm font-semibold text-slate-700">
                      {drivers.length === 0
                        ? 'هێشتا هیچ شۆفێرێک زیاد نەکراوە'
                        : 'هیچ شۆفێرێک بەم زانیارییە نەدۆزرایەوە'}
                    </p>
                    {drivers.length === 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingDriver(null);
                          setDriverModalOpen(true);
                        }}
                        className="min-h-[44px] px-5 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl inline-flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span>زیادکردنی یەکەم شۆفێر</span>
                      </button>
                    )}
                  </div>
                ) : (
                  <>
                    {/* Desktop Table */}
                    <div className="hidden md:block overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                            <th className="py-3 px-4 text-right font-semibold">شۆفێر</th>
                            <th className="py-3 px-4 text-right font-semibold">کۆد</th>
                            <th className="py-3 px-4 text-right font-semibold">تابلۆ / مۆبایل</th>
                            <th className="py-3 px-4 text-left font-semibold">لیتری ئەم مانگە</th>
                            <th className="py-3 px-4 text-left font-semibold">حیسابی ئەم مانگە</th>
                            <th className="py-3 px-4 text-left font-semibold">کردارەکان</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {filteredDrivers.map((d) => (
                            <tr
                              key={d.id}
                              className={`hover:bg-slate-50/80 transition-colors ${
                                !d.active ? 'opacity-60' : ''
                              }`}
                            >
                              <td className="py-3.5 px-4">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setStatementInitialMonth(getCurrentMonth());
                                    setStatementDriverId(d.id);
                                  }}
                                  className="font-bold text-slate-900 hover:text-amber-700 text-right"
                                >
                                  {d.name}
                                </button>
                                {!d.active && (
                                  <span className="mr-2 text-xs text-red-600">(ناچالاک)</span>
                                )}
                              </td>
                              <td className="py-3.5 px-4 font-mono-num font-semibold text-slate-700">
                                {d.code}
                              </td>
                              <td className="py-3.5 px-4 text-xs text-slate-500">
                                {[d.truckPlate, d.phone].filter(Boolean).join(' · ') || '—'}
                              </td>
                              <td className="py-3.5 px-4 text-left tabular-nums font-medium text-slate-800 whitespace-nowrap">
                                {formatLiters(d.monthLiters)}
                              </td>
                              <td className="py-3.5 px-4 text-left tabular-nums font-bold text-slate-900 whitespace-nowrap">
                                {formatIQD(d.monthCost)}
                              </td>
                              <td className="py-3.5 px-4">
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleSelectDriverForEntry(d);
                                      setTab('entry');
                                    }}
                                    className="min-h-[36px] px-2.5 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-lg whitespace-nowrap"
                                  >
                                    + سووتەمەنی
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setStatementInitialMonth(getCurrentMonth());
                                      setStatementDriverId(d.id);
                                    }}
                                    className="min-h-[36px] px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap"
                                  >
                                    کەشف
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingDriver(d);
                                      setDriverModalOpen(true);
                                    }}
                                    className="min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                                    aria-label="دەستکاریکردن"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeletingDriver(d)}
                                    className="min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                                    aria-label="سڕینەوە"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Mobile Cards */}
                    <div className="md:hidden divide-y divide-slate-100">
                      {filteredDrivers.map((d) => (
                        <div key={d.id} className={`p-4 space-y-3 ${!d.active ? 'opacity-60' : ''}`}>
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <div className="font-bold text-base text-slate-900 truncate">
                                {d.name}
                              </div>
                              <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2 mt-0.5">
                                <span className="font-mono-num font-semibold text-slate-700">
                                  کۆد: {d.code}
                                </span>
                                {d.truckPlate && (
                                  <>
                                    <span aria-hidden="true">·</span>
                                    <span>{d.truckPlate}</span>
                                  </>
                                )}
                              </div>
                            </div>
                            <div className="text-left shrink-0">
                              <div className="text-sm font-bold text-slate-900 tabular-nums">
                                {formatIQD(d.monthCost)}
                              </div>
                              <div className="text-xs text-slate-500 tabular-nums">
                                {formatLiters(d.monthLiters)}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => {
                                handleSelectDriverForEntry(d);
                                setTab('entry');
                              }}
                              className="flex-1 min-h-[42px] px-3 py-2 text-xs font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100 rounded-xl"
                            >
                              + سووتەمەنی
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setStatementInitialMonth(getCurrentMonth());
                                setStatementDriverId(d.id);
                              }}
                              className="flex-1 min-h-[42px] px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
                            >
                              کەشفی حیساب
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingDriver(d);
                                setDriverModalOpen(true);
                              }}
                              className="min-h-[42px] min-w-[42px] flex items-center justify-center text-slate-600 bg-slate-100 rounded-xl"
                              aria-label="دەستکاری"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeletingDriver(d)}
                              className="min-h-[42px] min-w-[42px] flex items-center justify-center text-red-600 bg-red-50 rounded-xl"
                              aria-label="سڕینەوە"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: FULL LEDGER */}
          {tab === 'ledger' && (
            <div className="space-y-5">
              <div className="bg-white border border-slate-200 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="relative lg:col-span-2">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={ledgerSearch}
                    onChange={(e) => setLedgerSearch(e.target.value)}
                    placeholder="گەڕان بە ناوی شۆفێر، کۆد، یان تێبینی..."
                    className="w-full min-h-[44px] pr-10 pl-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                  />
                </div>

                <select
                  value={ledgerMonth}
                  onChange={(e) => setLedgerMonth(e.target.value)}
                  className="min-h-[44px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900"
                >
                  {availableMonths.map((m) => (
                    <option key={m} value={m}>
                      {formatMonthLabel(m)}
                    </option>
                  ))}
                  <option value="all">هەموو مانگەکان</option>
                </select>

                <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl">
                  {(['all', 'diesel', 'gas'] as const).map((ft) => (
                    <button
                      key={ft}
                      type="button"
                      onClick={() => setLedgerFuelFilter(ft)}
                      className={`min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
                        ledgerFuelFilter === ft
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-600'
                      }`}
                    >
                      {ft === 'all' ? 'هەمووی' : ft === 'diesel' ? 'گازوایل' : 'بەنزین'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                {loadingLedger ? (
                  <div className="p-6 space-y-3">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-12 bg-slate-100 rounded-xl animate-pulse" />
                    ))}
                  </div>
                ) : ledgerEntries.length === 0 ? (
                  <div className="p-12 text-center text-sm text-slate-500">
                    هیچ تۆمارێک لەم فلتەرەدا نەدۆزرایەوە.
                  </div>
                ) : (
                  <>
                    <div className="hidden md:block overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                            <th className="py-3 px-4 text-right font-semibold">بەروار</th>
                            <th className="py-3 px-4 text-right font-semibold">شۆفێر</th>
                            <th className="py-3 px-4 text-right font-semibold">کۆد</th>
                            <th className="py-3 px-4 text-right font-semibold">جۆر</th>
                            <th className="py-3 px-4 text-left font-semibold">لیتر</th>
                            <th className="py-3 px-4 text-left font-semibold">نرخی لیتر</th>
                            <th className="py-3 px-4 text-left font-semibold">کۆی نرخ (IQD)</th>
                            <th className="py-3 px-4 text-left font-semibold">کردار</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {ledgerEntries.map((entry) => (
                            <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                                {entry.entryDate}
                              </td>
                              <td className="py-3.5 px-4 font-semibold text-slate-900">
                                {entry.driverName}
                                {entry.note && (
                                  <div className="text-xs font-normal text-slate-500 truncate max-w-[200px]">
                                    {entry.note}
                                  </div>
                                )}
                              </td>
                              <td className="py-3.5 px-4 font-mono-num text-slate-600">
                                {entry.driverCode}
                              </td>
                              <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                                {formatFuelType(entry.fuelType)}
                              </td>
                              <td className="py-3.5 px-4 text-left tabular-nums font-medium text-slate-900 whitespace-nowrap">
                                {formatLiters(entry.liters)}
                              </td>
                              <td className="py-3.5 px-4 text-left tabular-nums text-slate-600 whitespace-nowrap">
                                {formatIQD(entry.pricePerLiter)}
                              </td>
                              <td className="py-3.5 px-4 text-left tabular-nums font-bold text-slate-900 whitespace-nowrap">
                                {formatIQD(entry.totalPrice)}
                              </td>
                              <td className="py-3.5 px-4">
                                <div className="flex items-center justify-end gap-1">
                                  <button
                                    type="button"
                                    onClick={() => setEditingEntry(entry)}
                                    className="min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                                    aria-label="دەستکاریکردن"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeletingEntry(entry)}
                                    className="min-h-[36px] min-w-[36px] flex items-center justify-center text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                                    aria-label="سڕینەوە"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <div className="md:hidden divide-y divide-slate-100">
                      {ledgerEntries.map((entry) => (
                        <div key={entry.id} className="p-4 flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <div className="font-bold text-sm text-slate-900 truncate">
                              {entry.driverName}{' '}
                              <span className="font-mono-num font-normal text-slate-500">
                                ({entry.driverCode})
                              </span>
                            </div>
                            <div className="mt-1 text-xs text-slate-500 flex flex-wrap items-center gap-2">
                              <span className="font-mono-num">{entry.entryDate}</span>
                              <span aria-hidden="true">·</span>
                              <span>{formatFuelType(entry.fuelType)}</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-semibold text-slate-700">
                                {formatLiters(entry.liters)}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-sm font-bold text-slate-900 tabular-nums">
                              {formatIQD(entry.totalPrice)}
                            </span>
                            <button
                              type="button"
                              onClick={() => setEditingEntry(entry)}
                              className="min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-500 hover:bg-slate-100 rounded-xl"
                              aria-label="دەستکاریکردن"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeletingEntry(entry)}
                              className="min-h-[40px] min-w-[40px] flex items-center justify-center text-red-500 hover:bg-red-50 rounded-xl"
                              aria-label="سڕینەوە"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: MONTHLY REPORTS */}
          {tab === 'reports' && (
            <div className="space-y-6">
              {/* Print-only Header */}
              <div className="hidden print-only border-b-2 border-slate-900 pb-4 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900">
                      ڕۆژ سووتەمەنی — ڕاپۆرتی حیساباتی مانگانە
                    </h2>
                    <p className="text-sm text-slate-600 mt-1">
                      مانگ: {formatMonthLabel(reportMonth)} · بەرواری چاپ: {getTodayDate()}
                    </p>
                  </div>
                  <div className="text-left text-sm font-semibold">
                    دراو: دیناری عێراقی (IQD)
                  </div>
                </div>
              </div>

              {/* Filter & Export Bar */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 no-print">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
                  <select
                    value={reportMonth}
                    onChange={(e) => setReportMonth(e.target.value)}
                    className="min-h-[44px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900"
                  >
                    {availableMonths.map((m) => (
                      <option key={m} value={m}>
                        {formatMonthLabel(m)}
                      </option>
                    ))}
                  </select>

                  <div className="relative flex-1 max-w-sm">
                    <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={reportSearch}
                      onChange={(e) => setReportSearch(e.target.value)}
                      placeholder="گەڕان لە ڕاپۆرت..."
                      className="w-full min-h-[44px] pr-10 pl-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    disabled={!monthlyReport || filteredReportDrivers.length === 0}
                    onClick={() => exportMonthlyReportCsv(reportMonth, filteredReportDrivers)}
                    className="min-h-[44px] px-4 py-2 text-sm font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-2 disabled:opacity-50"
                  >
                    <Download className="w-4 h-4" />
                    <span>داگرتنی CSV</span>
                  </button>
                  <button
                    type="button"
                    disabled={!monthlyReport || filteredReportDrivers.length === 0}
                    onClick={() => window.print()}
                    className="min-h-[44px] px-4 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl flex items-center gap-2 disabled:opacity-50"
                  >
                    <Printer className="w-4 h-4" />
                    <span>چاپکردن</span>
                  </button>
                </div>
              </div>

              {/* Monthly KPI Summary Strip */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 print-break-avoid">
                <div className="bg-slate-900 text-white rounded-2xl p-5">
                  <div className="text-xs sm:text-sm text-slate-300">کۆی گشتی حیساب</div>
                  <div className="mt-2 text-xl sm:text-2xl font-bold text-amber-400 tabular-nums">
                    {loadingReport ? '...' : formatIQD(monthlyReport?.summary.totalCost ?? 0)}
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <div className="text-xs sm:text-sm text-slate-500">کۆی بڕی فرۆشراو</div>
                  <div className="mt-2 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
                    {loadingReport ? '...' : formatLiters(monthlyReport?.summary.totalLiters ?? 0)}
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <div className="text-xs sm:text-sm text-slate-500">شۆفێرانی ئەم مانگە</div>
                  <div className="mt-2 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
                    {loadingReport ? '...' : monthlyReport?.summary.driverCount ?? 0} شۆفێر
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <div className="text-xs sm:text-sm text-slate-500">ژمارەی تۆمارەکان</div>
                  <div className="mt-2 text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
                    {loadingReport ? '...' : monthlyReport?.summary.entryCount ?? 0} پسوڵە
                  </div>
                </div>
              </div>

              {/* Per-Driver Accounting Table */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                {loadingReport ? (
                  <div className="p-6 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-12 bg-slate-100 rounded-xl animate-pulse" />
                    ))}
                  </div>
                ) : filteredReportDrivers.length === 0 ? (
                  <div className="p-12 text-center text-sm text-slate-500">
                    هیچ فرۆشتنێک بۆ مانگی هەڵبژێردراو تۆمار نەکراوە.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                          <th className="py-3 px-4 text-right font-semibold">#</th>
                          <th className="py-3 px-4 text-right font-semibold">شۆفێر</th>
                          <th className="py-3 px-4 text-right font-semibold">کۆد</th>
                          <th className="py-3 px-4 text-left font-semibold">پسوڵە</th>
                          <th className="py-3 px-4 text-left font-semibold">گازوایل</th>
                          <th className="py-3 px-4 text-left font-semibold">بەنزین</th>
                          <th className="py-3 px-4 text-left font-semibold">کۆی لیتر</th>
                          <th className="py-3 px-4 text-left font-semibold">کۆی گشتی (IQD)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredReportDrivers.map((row, idx) => (
                          <tr
                            key={row.driverId}
                            onClick={() => {
                              setStatementInitialMonth(reportMonth);
                              setStatementDriverId(row.driverId);
                            }}
                            className="hover:bg-amber-50/50 cursor-pointer transition-colors"
                          >
                            <td className="py-3.5 px-4 text-slate-400 tabular-nums">
                              {idx + 1}
                            </td>
                            <td className="py-3.5 px-4 font-bold text-slate-900">
                              {row.driverName}
                              {row.truckPlate && (
                                <span className="mr-2 text-xs font-normal text-slate-500">
                                  ({row.truckPlate})
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 font-mono-num text-slate-700">
                              {row.driverCode}
                            </td>
                            <td className="py-3.5 px-4 text-left tabular-nums text-slate-600">
                              {row.entryCount}
                            </td>
                            <td className="py-3.5 px-4 text-left tabular-nums text-slate-600 whitespace-nowrap">
                              {formatLiters(row.dieselLiters)}
                            </td>
                            <td className="py-3.5 px-4 text-left tabular-nums text-slate-600 whitespace-nowrap">
                              {formatLiters(row.gasLiters)}
                            </td>
                            <td className="py-3.5 px-4 text-left tabular-nums font-semibold text-slate-900 whitespace-nowrap">
                              {formatLiters(row.totalLiters)}
                            </td>
                            <td className="py-3.5 px-4 text-left tabular-nums font-bold text-slate-900 whitespace-nowrap">
                              {formatIQD(row.totalCost)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (4 thumb-zone tabs) */}
      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 h-16 no-print"
        aria-label="بەشەکان"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors ${
                active ? 'text-amber-700 font-bold' : 'text-slate-500 font-medium'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[11px] leading-none whitespace-nowrap">
                {item.shortLabel}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Modals */}
      <DriverFormModal
        open={driverModalOpen}
        driver={editingDriver}
        existingCodes={drivers.map((d) => d.code)}
        onClose={() => setDriverModalOpen(false)}
        onSaved={() => {
          loadDrivers();
          if (tab === 'reports') loadMonthlyReport();
        }}
      />

      <FuelEntryEditModal
        open={Boolean(editingEntry)}
        entry={editingEntry}
        drivers={drivers}
        onClose={() => setEditingEntry(null)}
        onSaved={() => {
          loadRecentEntries();
          loadDrivers();
          if (tab === 'ledger') loadLedger();
          if (tab === 'reports') loadMonthlyReport();
        }}
      />

      <DriverStatementModal
        driverId={statementDriverId}
        initialMonth={statementInitialMonth}
        onClose={() => setStatementDriverId(null)}
      />

      <ConfirmModal
        open={Boolean(deletingDriver)}
        title="سڕینەوەی شۆفێر"
        description={
          deletingDriver
            ? `ئایا دڵنیایت لە سڕینەوەی شۆفێر «${deletingDriver.name}»؟ هەموو تۆمارەکانی سووتەمەنی ئەم شۆفێرەش دەسڕدرێنەوە.`
            : ''
        }
        loading={confirmBusy}
        onConfirm={confirmDeleteDriver}
        onCancel={() => setDeletingDriver(null)}
      />

      <ConfirmModal
        open={Boolean(deletingEntry)}
        title="سڕینەوەی تۆماری سووتەمەنی"
        description={
          deletingEntry
            ? `ئایا دڵنیایت لە سڕینەوەی ئەم تۆمارە (${deletingEntry.driverName} · ${formatLiters(deletingEntry.liters)} · ${formatIQD(deletingEntry.totalPrice)})؟`
            : ''
        }
        loading={confirmBusy}
        onConfirm={confirmDeleteEntry}
        onCancel={() => setDeletingEntry(null)}
      />
    </div>
  );
}
