import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, KeyRound, User, ArrowLeft } from 'lucide-react';
import { apiRequest, ApiError } from '../lib/api';
import type { Account } from '../types';
import { BrandMark } from './BrandMark';

interface LoginViewProps {
  onLoginSuccess: (token: string, user: Account) => void;
}

export function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    const trimmedCode = code.trim();
    if (!trimmedName || !trimmedCode) {
      setError('تکایە ناو و کۆدەکەت بنووسە.');
      return;
    }

    setSubmitting(true);
    try {
      const result = await apiRequest<{ token: string; user: Account }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ name: trimmedName, code: trimmedCode }),
      });
      onLoginSuccess(result.token, result.user);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError('نەتوانرا پەیوەندی بە سێرڤەرەوە بکرێت.');
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Right Panel (RTL Start): Operational Context */}
      <div className="lg:w-1/2 bg-slate-900 text-white px-6 py-10 sm:px-12 lg:px-16 lg:py-16 flex flex-col justify-between">
        <div className="flex items-center gap-3">
          <BrandMark className="w-10 h-10" />
          <span className="text-xl font-bold tracking-tight whitespace-nowrap">
            ڕۆژ سووتەمەنی
          </span>
        </div>

        <div className="my-10 lg:my-0 max-w-lg">
          <p className="text-sm font-medium text-amber-400 mb-3">
            بەڕێوەبردنی فرۆشتنی گازوایل و بەنزین
          </p>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight text-balance">
            سیستەمی تۆمارکردنی سووتەمەنی و حیسابی شۆفێران
          </h1>
          <p className="mt-5 text-base text-slate-300 leading-relaxed">
            چوونەژوورەوەی یەکگرتوو بۆ بەڕێوەبەرانی وێستگە و شۆفێرانی بارهەڵگر. هەموو حیسابات و نرخەکان بە دیناری عێراقی (IQD) تۆمار دەکرێن و دەپارێزرێن.
          </p>

          <div className="mt-8 pt-8 border-t border-slate-800 grid grid-cols-2 gap-6 text-sm">
            <div>
              <div className="text-amber-400 font-semibold">بۆ بەڕێوەبەر</div>
              <p className="mt-1 text-slate-400">
                تۆمارکردنی لیتر، بەڕێوەبردنی شۆفێران و ڕاپۆرتی مانگانە
              </p>
            </div>
            <div>
              <div className="text-amber-400 font-semibold">بۆ شۆفێران</div>
              <p className="mt-1 text-slate-400">
                بینینی مێژووی وەرگرتنی سووتەمەنی و کۆی حیسابی مانگانە
              </p>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-400 flex items-center gap-2">
          <span>دیناری عێراقی (IQD)</span>
          <span aria-hidden="true">·</span>
          <span>بەکارهێنان لە مۆبایل و کۆمپیوتەر</span>
        </div>
      </div>

      {/* Left Panel (RTL End): Login Form */}
      <div className="flex-1 flex items-center justify-center px-5 py-10 sm:px-10">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="mb-7">
            <h2 className="text-2xl font-bold text-slate-900">چوونەژوورەوە</h2>
            <p className="mt-1.5 text-sm text-slate-500">
              ناو و کۆدی تایبەتی خۆت بنووسە بۆ چوونە ناو هەژمارەکەت
            </p>
          </div>

          {error && (
            <div
              role="alert"
              className="mb-5 px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700 leading-relaxed"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="login-name" className="block text-sm font-semibold text-slate-800 mb-2">
                ناو (Name)
              </label>
              <div className="relative">
                <User className="w-5 h-5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="login-name"
                  type="text"
                  autoComplete="username"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="ناوەکەت بنووسە..."
                  className="w-full min-h-[48px] pr-11 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600 transition-colors"
                  disabled={submitting}
                />
              </div>
            </div>

            <div>
              <label htmlFor="login-code" className="block text-sm font-semibold text-slate-800 mb-2">
                کۆد (Code)
              </label>
              <div className="relative">
                <KeyRound className="w-5 h-5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="login-code"
                  type={showCode ? 'text' : 'password'}
                  inputMode="text"
                  autoComplete="current-password"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="کۆدی تایبەت بنووسە..."
                  className="w-full min-h-[48px] pr-11 pl-12 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-mono-num text-slate-900 placeholder:text-slate-400 placeholder:font-sans focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600 transition-colors"
                  disabled={submitting}
                />
                <button
                  type="button"
                  onClick={() => setShowCode((v) => !v)}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center absolute left-1 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 rounded-lg"
                  aria-label={showCode ? 'شاردنەوەی کۆد' : 'نیشاندانی کۆد'}
                >
                  {showCode ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[48px] px-5 py-3 bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-base font-semibold rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
            >
              <span>{submitting ? 'چاوەڕوانبە...' : 'چوونەژوورەوە'}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </form>

          <p className="mt-6 pt-5 border-t border-slate-100 text-xs text-slate-500 leading-relaxed">
            شۆفێرانی بەڕێز: تکایە ئەو ناو و کۆدە بەکاربهێنن کە لەلایەن بەڕێوەبەری وێستگەوە پێتان دراوە.
          </p>
        </div>
      </div>
    </div>
  );
}
