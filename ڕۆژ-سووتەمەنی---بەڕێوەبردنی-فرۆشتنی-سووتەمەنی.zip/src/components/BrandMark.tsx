export function BrandMark({ className = 'w-9 h-9' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect width="40" height="40" rx="10" fill="#0F172A" />
      <path
        d="M20 7.5C20 7.5 11.5 16.8 11.5 22.8C11.5 27.6 15.3 31.5 20 31.5C24.7 31.5 28.5 27.6 28.5 22.8C28.5 16.8 20 7.5 20 7.5Z"
        fill="#D97706"
      />
      <path
        d="M20 14.5C20 14.5 15.8 19.6 15.8 23.1C15.8 25.5 17.7 27.4 20 27.4C22.3 27.4 24.2 25.5 24.2 23.1C24.2 19.6 20 14.5 20 14.5Z"
        fill="#FEF3C7"
      />
    </svg>
  );
}
