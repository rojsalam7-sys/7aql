import { useEffect, useState } from 'react';
import { Calendar, Droplets, LogOut, Printer, Wallet } from 'lucide-react';
import { apiRequest, ApiError } from '../lib/api';
import {
  formatFuelType,
  formatIQD,
  formatLiters,
  formatMonthLabel,
  getCurrentMonth,
} from '../lib/format';
import type { Account, DriverStatementResponse } from '../types';
import { BrandMark } from './BrandMark';

interface DriverDashboardProps {
  user: Account;
  onLogout: () => void;
}

export function DriverDashboard({ user, onLogout }: DriverDashboardProps) {
  const [month, setMonth] = useState<string>(getCurrentMonth());
  const [data, setData] = useState<DriverStatementResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const res = await apiRequest<DriverStatementResponse>(
          `/api/driver-statement?month=${encodeURIComponent(month)}`
        );
        if (active) setData(res);
      } catch (err) {
        if (!active) return;
        if (err instanceof ApiError && err.status === 401) {
          onLogout();
          return;
        }
        setError(err instanceof Error ? err.message : 'هەڵە لە هێنانی زانیارییەکان.');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => {
      active = false;
    };
  }, [month, onLogout]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 no-print">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <BrandMark className="w-8 h-8 shrink-0" />
            <span className="font-bold text-slate-900 text-base whitespace-nowrap truncate">
              ڕۆژ سووتەمەنی
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              className="min-h-[40px] px-3 py-2 text-xs sm:text-sm font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">چاپکردن</span>
            </button>
            <button
              type="button"
              onClick={onLogout}
              className="min-h-[40px] px-3.5 py-2 text-xs sm:text-sm font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              <span>دەرچوون</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Driver Header & Month Selector */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1">
              <span>هەژماری شۆفێر (تەنها بۆ بینین)</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num">کۆد: {user.code}</span>
              {user.truckPlate && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>تابلۆ: {user.truckPlate}</span>
                </>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              بەخێربێیت، {user.name}
            </h1>
          </div>

          <div className="flex items-center gap-2 no-print">
            <label htmlFor="driver-month-select" className="text-sm font-medium text-slate-600 whitespace-nowrap">
              مانگ:
            </label>
            <div className="relative flex-1 sm:flex-initial">
              <Calendar className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                id="driver-month-select"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="w-full sm:w-56 min-h-[44px] pr-9 pl-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              >
                {(data?.availableMonths ?? [getCurrentMonth()]).map((m) => (
                  <option key={m} value={m}>
                    {formatMonthLabel(m)}
                  </option>
                ))}
                <option value="all">هەموو مانگەکان</option>
              </select>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
            {error}
          </div>
        )}

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6">
            <div className="flex items-center justify-between text-slate-300 text-sm mb-2">
              <span>{month === 'all' ? 'کۆی حیسابی گشتی' : 'کۆی حیسابی ئەم مانگە'}</span>
              <Wallet className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold tabular-nums text-amber-400">
              {loading && !data ? '...' : formatIQD(data?.summary.totalCost ?? 0)}
            </div>
            <div className="mt-2 text-xs text-slate-400">
              {formatMonthLabel(month)} · {data?.summary.entryCount ?? 0} وەرگرتن
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6">
            <div className="flex items-center justify-between text-slate-500 text-sm mb-2">
              <span>{month === 'all' ? 'کۆی لیتری گشتی' : 'کۆی لیتری ئەم مانگە'}</span>
              <Droplets className="w-5 h-5 text-amber-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-bold tabular-nums text-slate-900">
              {loading && !data ? '...' : formatLiters(data?.summary.totalLiters ?? 0)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-2">
              <span>گازوایل: {formatLiters(data?.summary.dieselLiters ?? 0)}</span>
              <span aria-hidden="true">·</span>
              <span>بەنزین: {formatLiters(data?.summary.gasLiters ?? 0)}</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 sm:col-span-2 lg:col-span-1">
            <div className="text-slate-500 text-sm mb-2">کۆی گشتی هەموو کاتەکان</div>
            <div className="text-xl sm:text-2xl font-bold tabular-nums text-slate-900">
              {loading && !data ? '...' : formatIQD(data?.lifetime.totalCost ?? 0)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-2">
              <span>{formatLiters(data?.lifetime.totalLiters ?? 0)}</span>
              <span aria-hidden="true">·</span>
              <span>{data?.lifetime.entryCount ?? 0} جار</span>
            </div>
          </div>
        </div>

        {/* Transaction History */}
        <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              مێژووی وەرگرتنی سووتەمەنی
            </h2>
            <span className="text-xs text-slate-500 tabular-nums">
              {data?.entries.length ?? 0} تۆمار
            </span>
          </div>

          {loading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-12 bg-slate-100 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : !data || data.entries.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-sm font-medium text-slate-700">
                هیچ تۆمارێکی سووتەمەنی لەم ماوەیەدا نییە.
              </p>
              <p className="mt-1 text-xs text-slate-500">
                کاتێک لە وێستگە سووتەمەنی وەردەگریت، لێرەدا دەردەکەوێت.
              </p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs">
                      <th className="py-3 px-4 text-right font-semibold">بەروار</th>
                      <th className="py-3 px-4 text-right font-semibold">جۆر</th>
                      <th className="py-3 px-4 text-left font-semibold">بڕ (لیتر)</th>
                      <th className="py-3 px-4 text-left font-semibold">نرخی لیتر</th>
                      <th className="py-3 px-4 text-left font-semibold">کۆی نرخ (IQD)</th>
                      <th className="py-3 px-4 text-right font-semibold">تێبینی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.entries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                          {entry.entryDate}
                        </td>
                        <td className="py-3.5 px-4 text-slate-800 whitespace-nowrap">
                          {formatFuelType(entry.fuelType)}
                        </td>
                        <td className="py-3.5 px-4 text-left font-semibold tabular-nums text-slate-900 whitespace-nowrap">
                          {formatLiters(entry.liters)}
                        </td>
                        <td className="py-3.5 px-4 text-left tabular-nums text-slate-600 whitespace-nowrap">
                          {formatIQD(entry.pricePerLiter)}
                        </td>
                        <td className="py-3.5 px-4 text-left font-bold tabular-nums text-slate-900 whitespace-nowrap">
                          {formatIQD(entry.totalPrice)}
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 max-w-xs truncate">
                          {entry.note || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden divide-y divide-slate-100">
                {data.entries.map((entry) => (
                  <div key={entry.id} className="p-4 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono-num text-slate-700 font-medium">
                          {entry.entryDate}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{formatFuelType(entry.fuelType)}</span>
                      </div>
                      <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
                        {formatLiters(entry.liters)}
                      </div>
                      {entry.note && (
                        <p className="mt-0.5 text-xs text-slate-500 truncate">{entry.note}</p>
                      )}
                    </div>

                    <div className="text-left shrink-0">
                      <div className="text-base font-bold text-slate-900 tabular-nums">
                        {formatIQD(entry.totalPrice)}
                      </div>
                      <div className="text-xs text-slate-500 tabular-nums">
                        لیتر: {formatIQD(entry.pricePerLiter)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>
      </main>
    </div>
  );
}
