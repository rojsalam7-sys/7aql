import { useEffect, useState, type FormEvent } from 'react';
import { RefreshCw, X } from 'lucide-react';
import { apiRequest, ApiError } from '../lib/api';
import type { DriverSummary } from '../types';

interface DriverFormModalProps {
  open: boolean;
  driver: DriverSummary | null;
  existingCodes: string[];
  onClose: () => void;
  onSaved: () => void;
}

export function DriverFormModal({
  open,
  driver,
  existingCodes,
  onClose,
  onSaved,
}: DriverFormModalProps) {
  const isEditing = Boolean(driver);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [truckPlate, setTruckPlate] = useState('');
  const [phone, setPhone] = useState('');
  const [active, setActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    if (driver) {
      setName(driver.name);
      setCode(driver.code);
      setTruckPlate(driver.truckPlate);
      setPhone(driver.phone);
      setActive(driver.active);
    } else {
      setName('');
      setCode('');
      setTruckPlate('');
      setPhone('');
      setActive(true);
    }
  }, [open, driver]);

  if (!open) return null;

  function generateUniqueCode() {
    const used = new Set(existingCodes.map((c) => c.trim()));
    for (let i = 0; i < 40; i++) {
      const candidate = String(Math.floor(1000 + Math.random() * 9000));
      if (!used.has(candidate)) {
        setCode(candidate);
        return;
      }
    }
    setCode(String(Math.floor(10000 + Math.random() * 90000)));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!name.trim() || name.trim().length < 2) {
      setError('تکایە ناوی شۆفێر بنووسە.');
      return;
    }
    if (!code.trim() || code.trim().length < 2) {
      setError('تکایە کۆدێکی بێهاوتا بنووسە.');
      return;
    }

    setSaving(true);
    try {
      if (driver) {
        await apiRequest(`/api/drivers/${driver.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            name: name.trim(),
            code: code.trim(),
            truckPlate: truckPlate.trim(),
            phone: phone.trim(),
            active,
          }),
        });
      } else {
        await apiRequest('/api/drivers', {
          method: 'POST',
          body: JSON.stringify({
            name: name.trim(),
            code: code.trim(),
            truckPlate: truckPlate.trim(),
            phone: phone.trim(),
          }),
        });
      }
      onSaved();
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'هەڵە لە پاشەکەوتکردن.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full sm:max-w-lg bg-white border border-slate-200 rounded-t-2xl sm:rounded-2xl shadow-xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">
            {isEditing ? 'دەستکاریکردنی شۆفێر' : 'زیادکردنی شۆفێری نوێ'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            aria-label="داخستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label htmlFor="driver-name" className="block text-sm font-semibold text-slate-800 mb-1.5">
              ناوی شۆفێر *
            </label>
            <input
              id="driver-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="نموونە: کاروان ئەحمەد"
              className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
            />
          </div>

          <div>
            <label htmlFor="driver-code" className="block text-sm font-semibold text-slate-800 mb-1.5">
              کۆدی تایبەت *
            </label>
            <div className="flex items-center gap-2">
              <input
                id="driver-code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="نموونە: 1045"
                className="flex-1 min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
              <button
                type="button"
                onClick={generateUniqueCode}
                className="min-h-[46px] px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <RefreshCw className="w-4 h-4" />
                <span>کۆدی هەڕەمەکی</span>
              </button>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              شۆفێر بەم ناو و کۆدە دەتوانێت بچێتە ناو هەژمارەکەی.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="driver-plate" className="block text-sm font-semibold text-slate-800 mb-1.5">
                ژمارەی تابلۆ (ئارەزوومەندانە)
              </label>
              <input
                id="driver-plate"
                type="text"
                value={truckPlate}
                onChange={(e) => setTruckPlate(e.target.value)}
                placeholder="نموونە: 21 B 4590"
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
            </div>

            <div>
              <label htmlFor="driver-phone" className="block text-sm font-semibold text-slate-800 mb-1.5">
                مۆبایل (ئارەزوومەندانە)
              </label>
              <input
                id="driver-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0750..."
                className="w-full min-h-[46px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono-num text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600"
              />
            </div>
          </div>

          {isEditing && (
            <div className="pt-2 flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div>
                <div className="text-sm font-semibold text-slate-800">دۆخی هەژمار</div>
                <div className="text-xs text-slate-500">
                  شۆفێری ناچالاک ناتوانێت بچێتە ژوورەوە
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActive((v) => !v)}
                className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {active ? 'چالاکە' : 'ناچالاکە'}
              </button>
            </div>
          )}

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="min-h-[46px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              پاشگەزبوونەوە
            </button>
            <button
              type="submit"
              disabled={saving}
              className="min-h-[46px] px-6 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors disabled:opacity-60"
            >
              {saving ? 'پاشەکەوت دەکرێت...' : isEditing ? 'نوێکردنەوە' : 'زیادکردنی شۆفێر'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
