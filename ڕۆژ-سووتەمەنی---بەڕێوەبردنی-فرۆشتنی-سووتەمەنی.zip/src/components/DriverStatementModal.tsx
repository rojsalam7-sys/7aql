import { useEffect, useState } from 'react';
import { Download, Printer, X } from 'lucide-react';
import { apiRequest } from '../lib/api';
import {
  exportDriverStatementCsv,
  formatFuelType,
  formatIQD,
  formatLiters,
  formatMonthLabel,
  getCurrentMonth,
} from '../lib/format';
import type { DriverStatementResponse } from '../types';

interface DriverStatementModalProps {
  driverId: number | null;
  initialMonth?: string;
  onClose: () => void;
}

export function DriverStatementModal({
  driverId,
  initialMonth,
  onClose,
}: DriverStatementModalProps) {
  const [month, setMonth] = useState<string>(initialMonth || getCurrentMonth());
  const [statement, setStatement] = useState<DriverStatementResponse | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialMonth) setMonth(initialMonth);
  }, [initialMonth]);

  useEffect(() => {
    if (!driverId) return;
    let active = true;
    async function load() {
      setLoading(true);
      try {
        const res = await apiRequest<DriverStatementResponse>(
          `/api/driver-statement?driverId=${driverId}&month=${encodeURIComponent(month)}`
        );
        if (active) setStatement(res);
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => {
      active = false;
    };
  }, [driverId, month]);

  if (!driverId) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full sm:max-w-3xl bg-white border border-slate-200 rounded-t-2xl sm:rounded-2xl shadow-xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4 shrink-0">
          <div className="min-w-0">
            <div className="text-xs text-slate-500 flex items-center gap-2">
              <span>کەشفی حیسابی شۆفێر</span>
              {statement && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">کۆد: {statement.driver.code}</span>
                </>
              )}
            </div>
            <h3 className="text-lg font-bold text-slate-900 truncate">
              {statement ? statement.driver.name : 'بارکردن...'}
            </h3>
          </div>

          <div className="flex items-center gap-2 shrink-0 no-print">
            {statement && statement.entries.length > 0 && (
              <>
                <button
                  type="button"
                  onClick={() =>
                    exportDriverStatementCsv(statement.driver.name, month, statement.entries)
                  }
                  className="min-h-[40px] px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="min-h-[40px] px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span className="hidden sm:inline">چاپ</span>
                </button>
              </>
            )}
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              aria-label="داخستن"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <select
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="min-h-[44px] px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 no-print"
            >
              {(statement?.availableMonths ?? [getCurrentMonth()]).map((m) => (
                <option key={m} value={m}>
                  {formatMonthLabel(m)}
                </option>
              ))}
              <option value="all">هەموو مانگەکان</option>
            </select>

            {statement && (
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <div>
                  <span className="text-slate-500">کۆی لیتر: </span>
                  <span className="font-bold text-slate-900 tabular-nums">
                    {formatLiters(statement.summary.totalLiters)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">کۆی حیساب: </span>
                  <span className="font-bold text-amber-700 tabular-nums">
                    {formatIQD(statement.summary.totalCost)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {loading ? (
            <div className="space-y-3 py-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-11 bg-slate-100 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : !statement || statement.entries.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-500">
              هیچ تۆمارێکی سووتەمەنی لەم ماوەیەدا نییە.
            </div>
          ) : (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <th className="py-2.5 px-3 text-right font-semibold">بەروار</th>
                    <th className="py-2.5 px-3 text-right font-semibold">جۆر</th>
                    <th className="py-2.5 px-3 text-left font-semibold">لیتر</th>
                    <th className="py-2.5 px-3 text-left font-semibold">نرخی لیتر</th>
                    <th className="py-2.5 px-3 text-left font-semibold">کۆی نرخ (IQD)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {statement.entries.map((entry) => (
                    <tr key={entry.id}>
                      <td className="py-3 px-3 font-mono-num text-slate-700 whitespace-nowrap">
                        {entry.entryDate}
                      </td>
                      <td className="py-3 px-3 text-slate-800 whitespace-nowrap">
                        {formatFuelType(entry.fuelType)}
                      </td>
                      <td className="py-3 px-3 text-left tabular-nums font-medium text-slate-900 whitespace-nowrap">
                        {formatLiters(entry.liters)}
                      </td>
                      <td className="py-3 px-3 text-left tabular-nums text-slate-600 whitespace-nowrap">
                        {formatIQD(entry.pricePerLiter)}
                      </td>
                      <td className="py-3 px-3 text-left tabular-nums font-bold text-slate-900 whitespace-nowrap">
                        {formatIQD(entry.totalPrice)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
