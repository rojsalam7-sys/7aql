import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import dotenv from 'dotenv';
import express, { type NextFunction, type Request, type Response } from 'express';
import { createServer as createViteServer } from 'vite';

dotenv.config();

interface AccountRow {
  id: number;
  name: string;
  code: string;
  role: 'admin' | 'driver';
  phone: string;
  truck_plate: string;
  active: number;
  is_protected: number;
  created_at: string;
}

interface AuthedRequest extends Request {
  user?: AccountRow;
}

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'fuel.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK(role IN ('admin', 'driver')),
    phone TEXT NOT NULL DEFAULT '',
    truck_plate TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1,
    is_protected INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS fuel_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    driver_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    fuel_type TEXT NOT NULL DEFAULT 'diesel' CHECK(fuel_type IN ('diesel', 'gas')),
    liters REAL NOT NULL CHECK(liters > 0),
    price_per_liter REAL NOT NULL CHECK(price_per_liter >= 0),
    total_price REAL NOT NULL CHECK(total_price >= 0),
    entry_date TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_by INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_fuel_entries_driver_date ON fuel_entries(driver_id, entry_date DESC);
  CREATE INDEX IF NOT EXISTS idx_fuel_entries_date ON fuel_entries(entry_date DESC);
  CREATE INDEX IF NOT EXISTS idx_accounts_role ON accounts(role, active);

  CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

function getOrCreateSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) {
    return process.env.SESSION_SECRET;
  }
  const existing = db.prepare('SELECT value FROM app_meta WHERE key = ?').get('session_secret') as { value: string } | undefined;
  if (existing?.value) {
    return existing.value;
  }
  const generated = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT OR REPLACE INTO app_meta (key, value) VALUES (?, ?)').run('session_secret', generated);
  return generated;
}

const SESSION_SECRET = getOrCreateSecret();

// Ensure dedicated main admin account (ROJ / 751175) and pre-configured admin exist
function ensurePreconfiguredAdmins() {
  const existingRoj = db.prepare('SELECT id, name, code, role FROM accounts WHERE code = ?').get('751175') as AccountRow | undefined;
  if (!existingRoj) {
    db.prepare(
      `INSERT INTO accounts (name, code, role, phone, truck_plate, active, is_protected)
       VALUES (?, ?, 'admin', '', '', 1, 1)`
    ).run('ROJ', '751175');
  } else if (existingRoj.role !== 'admin' || existingRoj.name.toUpperCase() !== 'ROJ') {
    db.prepare(`UPDATE accounts SET name = 'ROJ', role = 'admin', active = 1, is_protected = 1 WHERE id = ?`).run(existingRoj.id);
  }

  const seededAdmins = db.prepare('SELECT value FROM app_meta WHERE key = ?').get('seeded_admins_v1') as { value: string } | undefined;
  if (!seededAdmins) {
    const secondaryExists = db.prepare('SELECT id FROM accounts WHERE code = ?').get('100200');
    if (!secondaryExists) {
      db.prepare(
        `INSERT INTO accounts (name, code, role, phone, truck_plate, active, is_protected)
         VALUES (?, ?, 'admin', '', '', 1, 0)`
      ).run('Admin', '100200');
    }
    db.prepare('INSERT OR REPLACE INTO app_meta (key, value) VALUES (?, ?)').run('seeded_admins_v1', '1');
  }
}

ensurePreconfiguredAdmins();

function base64UrlEncode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64url');
}

function base64UrlDecode(input: string): string {
  return Buffer.from(input, 'base64url').toString('utf8');
}

function signToken(accountId: number, role: 'admin' | 'driver'): string {
  const now = Math.floor(Date.now() / 1000);
  const payload = JSON.stringify({
    sub: accountId,
    role,
    iat: now,
    exp: now + 60 * 60 * 24 * 30, // 30 days
  });
  const encodedPayload = base64UrlEncode(payload);
  const signature = crypto.createHmac('sha256', SESSION_SECRET).update(encodedPayload).digest('base64url');
  return `${encodedPayload}.${signature}`;
}

function verifyToken(token: string): { sub: number; role: 'admin' | 'driver'; exp: number } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encodedPayload, signature] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(encodedPayload).digest('base64url');
  const sigBuf = Buffer.from(signature);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(base64UrlDecode(encodedPayload)) as { sub: number; role: 'admin' | 'driver'; exp: number };
    if (!parsed.sub || !parsed.exp || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function mapAccount(row: AccountRow) {
  return {
    id: row.id,
    name: row.name,
    code: row.code,
    role: row.role,
    phone: row.phone,
    truckPlate: row.truck_plate,
    active: row.active === 1,
    createdAt: row.created_at,
  };
}

function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getCurrentMonthString(): string {
  return getTodayDateString().slice(0, 7);
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'تکایە سەرەتا بچۆ ژوورەوە.' });
    return;
  }
  const token = authHeader.slice(7).trim();
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: 'کاتی چوونەژوورەوە بەسەرچووە، تکایە دووبارە بچۆ ژوورەوە.' });
    return;
  }
  const user = db.prepare('SELECT * FROM accounts WHERE id = ? AND active = 1').get(payload.sub) as AccountRow | undefined;
  if (!user) {
    res.status(401).json({ error: 'هەژمارەکە نەدۆزرایەوە یان ناچالاک کراوە.' });
    return;
  }
  req.user = user;
  next();
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'admin') {
    res.status(403).json({ error: 'ئەم کردارە تەنها بۆ بەڕێوەبەر ڕێگەپێدراوە.' });
    return;
  }
  next();
}

const app = express();
app.use(express.json({ limit: '1mb' }));

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

// Unified Login (Name + Code)
app.post('/api/auth/login', (req, res) => {
  const rawName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const rawCode = typeof req.body?.code === 'string' ? req.body.code.trim() : String(req.body?.code ?? '').trim();

  if (!rawName || !rawCode) {
    res.status(400).json({ error: 'تکایە ناو و کۆد بە تەواوی بنووسە.' });
    return;
  }

  const user = db
    .prepare(
      `SELECT * FROM accounts
       WHERE LOWER(TRIM(name)) = LOWER(?) AND TRIM(code) = ?`
    )
    .get(rawName, rawCode) as AccountRow | undefined;

  if (!user) {
    res.status(401).json({ error: 'ناو یان کۆد هەڵەیە. تکایە دڵنیابە و دووبارە هەوڵبدە.' });
    return;
  }

  if (user.active !== 1) {
    res.status(403).json({ error: 'ئەم هەژمارە لەلایەن بەڕێوەبەرەوە ناچالاک کراوە.' });
    return;
  }

  const token = signToken(user.id, user.role);
  res.json({
    token,
    user: mapAccount(user),
  });
});

app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
  res.json({ user: mapAccount(req.user!) });
});

// Admin: List drivers with monthly & lifetime summaries
app.get('/api/drivers', requireAuth, requireAdmin, (req, res) => {
  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
  const month = typeof req.query.month === 'string' && /^\d{4}-\d{2}$/.test(req.query.month)
    ? req.query.month
    : getCurrentMonthString();

  const rows = db
    .prepare(
      `SELECT
        a.*,
        COUNT(f.id) AS entry_count,
        COALESCE(SUM(f.liters), 0) AS total_liters,
        COALESCE(SUM(f.total_price), 0) AS total_cost,
        COALESCE(SUM(CASE WHEN substr(f.entry_date, 1, 7) = ? THEN f.liters ELSE 0 END), 0) AS month_liters,
        COALESCE(SUM(CASE WHEN substr(f.entry_date, 1, 7) = ? THEN f.total_price ELSE 0 END), 0) AS month_cost,
        MAX(f.entry_date) AS last_entry_date
      FROM accounts a
      LEFT JOIN fuel_entries f ON f.driver_id = a.id
      WHERE a.role = 'driver'
      GROUP BY a.id
      ORDER BY a.active DESC, a.name COLLATE NOCASE ASC`
    )
    .all(month, month) as Array<
      AccountRow & {
        entry_count: number;
        total_liters: number;
        total_cost: number;
        month_liters: number;
        month_cost: number;
        last_entry_date: string | null;
      }
    >;

  const filtered = search
    ? rows.filter(
        (r) =>
          r.name.toLowerCase().includes(search) ||
          r.code.toLowerCase().includes(search) ||
          r.truck_plate.toLowerCase().includes(search) ||
          r.phone.toLowerCase().includes(search)
      )
    : rows;

  res.json({
    month,
    drivers: filtered.map((r) => ({
      ...mapAccount(r),
      entryCount: Number(r.entry_count),
      totalLiters: Number(r.total_liters),
      totalCost: Number(r.total_cost),
      monthLiters: Number(r.month_liters),
      monthCost: Number(r.month_cost),
      lastEntryDate: r.last_entry_date,
    })),
  });
});

// Admin: Create driver
app.post('/api/drivers', requireAuth, requireAdmin, (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const code = typeof req.body?.code === 'string' ? req.body.code.trim() : String(req.body?.code ?? '').trim();
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : '';
  const truckPlate = typeof req.body?.truckPlate === 'string' ? req.body.truckPlate.trim() : '';

  if (!name || name.length < 2) {
    res.status(400).json({ error: 'تکایە ناوی شۆفێر بنووسە (لایەنی کەم ٢ پیت).' });
    return;
  }
  if (!code || code.length < 2) {
    res.status(400).json({ error: 'تکایە کۆدێکی بێهاوتا بۆ شۆفێر بنووسە.' });
    return;
  }

  const codeConflict = db.prepare('SELECT id FROM accounts WHERE TRIM(code) = ?').get(code);
  if (codeConflict) {
    res.status(409).json({ error: 'ئەم کۆدە پێشتر بۆ کەسێکی تر بەکارهێنراوە. تکایە کۆدێکی جیاواز هەڵبژێرە.' });
    return;
  }

  const info = db
    .prepare(
      `INSERT INTO accounts (name, code, role, phone, truck_plate, active, is_protected)
       VALUES (?, ?, 'driver', ?, ?, 1, 0)`
    )
    .run(name, code, phone, truckPlate);

  const created = db.prepare('SELECT * FROM accounts WHERE id = ?').get(info.lastInsertRowid) as AccountRow;
  res.status(201).json({ driver: mapAccount(created) });
});

// Admin: Update driver
app.put('/api/drivers/:id', requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'ناسنامەی شۆفێر هەڵەیە.' });
    return;
  }

  const existing = db.prepare("SELECT * FROM accounts WHERE id = ? AND role = 'driver'").get(id) as AccountRow | undefined;
  if (!existing) {
    res.status(404).json({ error: 'شۆفێرەکە نەدۆزرایەوە.' });
    return;
  }

  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : existing.name;
  const code = typeof req.body?.code === 'string' ? req.body.code.trim() : existing.code;
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : existing.phone;
  const truckPlate = typeof req.body?.truckPlate === 'string' ? req.body.truckPlate.trim() : existing.truck_plate;
  const active = typeof req.body?.active === 'boolean' ? (req.body.active ? 1 : 0) : existing.active;

  if (!name || name.length < 2) {
    res.status(400).json({ error: 'تکایە ناوی شۆفێر بنووسە.' });
    return;
  }
  if (!code || code.length < 2) {
    res.status(400).json({ error: 'تکایە کۆدی شۆفێر بنووسە.' });
    return;
  }

  const codeConflict = db.prepare('SELECT id FROM accounts WHERE TRIM(code) = ? AND id != ?').get(code, id);
  if (codeConflict) {
    res.status(409).json({ error: 'ئەم کۆدە پێشتر بۆ هەژمارێکی تر تۆمارکراوە.' });
    return;
  }

  db.prepare(
    `UPDATE accounts
     SET name = ?, code = ?, phone = ?, truck_plate = ?, active = ?
     WHERE id = ?`
  ).run(name, code, phone, truckPlate, active, id);

  const updated = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id) as AccountRow;
  res.json({ driver: mapAccount(updated) });
});

// Admin: Delete driver
app.delete('/api/drivers/:id', requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'ناسنامەی شۆفێر هەڵەیە.' });
    return;
  }

  const existing = db.prepare("SELECT * FROM accounts WHERE id = ? AND role = 'driver'").get(id) as AccountRow | undefined;
  if (!existing) {
    res.status(404).json({ error: 'شۆفێرەکە نەدۆزرایەوە.' });
    return;
  }

  db.prepare('DELETE FROM accounts WHERE id = ?').run(id);
  res.json({ deleted: true });
});

// Admin: List fuel entries
app.get('/api/fuel-entries', requireAuth, requireAdmin, (req, res) => {
  const month = typeof req.query.month === 'string' ? req.query.month.trim() : '';
  const driverId = req.query.driverId ? Number(req.query.driverId) : null;
  const fuelType = typeof req.query.fuelType === 'string' ? req.query.fuelType.trim() : '';
  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
  const limit = Math.min(Math.max(Number(req.query.limit || 250), 1), 1000);

  const clauses: string[] = [];
  const params: Array<string | number> = [];

  if (month && /^\d{4}-\d{2}$/.test(month)) {
    clauses.push('substr(f.entry_date, 1, 7) = ?');
    params.push(month);
  }
  if (driverId && Number.isInteger(driverId)) {
    clauses.push('f.driver_id = ?');
    params.push(driverId);
  }
  if (fuelType === 'diesel' || fuelType === 'gas') {
    clauses.push('f.fuel_type = ?');
    params.push(fuelType);
  }
  if (search) {
    clauses.push('(LOWER(a.name) LIKE ? OR LOWER(a.code) LIKE ? OR LOWER(f.note) LIKE ? OR LOWER(a.truck_plate) LIKE ?)');
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }

  const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
  params.push(limit);

  const rows = db
    .prepare(
      `SELECT
        f.*,
        a.name AS driver_name,
        a.code AS driver_code,
        a.truck_plate AS driver_truck_plate
      FROM fuel_entries f
      JOIN accounts a ON a.id = f.driver_id
      ${whereSql}
      ORDER BY f.entry_date DESC, f.id DESC
      LIMIT ?`
    )
    .all(...params) as Array<{
      id: number;
      driver_id: number;
      driver_name: string;
      driver_code: string;
      driver_truck_plate: string;
      fuel_type: 'diesel' | 'gas';
      liters: number;
      price_per_liter: number;
      total_price: number;
      entry_date: string;
      note: string;
      created_at: string;
    }>;

  res.json({
    entries: rows.map((r) => ({
      id: r.id,
      driverId: r.driver_id,
      driverName: r.driver_name,
      driverCode: r.driver_code,
      driverTruckPlate: r.driver_truck_plate,
      fuelType: r.fuel_type,
      liters: Number(r.liters),
      pricePerLiter: Number(r.price_per_liter),
      totalPrice: Number(r.total_price),
      entryDate: r.entry_date,
      note: r.note,
      createdAt: r.created_at,
    })),
  });
});

// Admin: Add fuel entry
app.post('/api/fuel-entries', requireAuth, requireAdmin, (req: AuthedRequest, res) => {
  const driverId = Number(req.body?.driverId);
  const fuelType = req.body?.fuelType === 'gas' ? 'gas' : 'diesel';
  const liters = Number(req.body?.liters);
  const pricePerLiter = Number(req.body?.pricePerLiter ?? 0);
  const rawTotalPrice = req.body?.totalPrice;
  const totalPrice =
    rawTotalPrice !== undefined && rawTotalPrice !== null && rawTotalPrice !== ''
      ? Number(rawTotalPrice)
      : Math.round(liters * pricePerLiter);
  const entryDate = typeof req.body?.entryDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.entryDate)
    ? req.body.entryDate
    : getTodayDateString();
  const note = typeof req.body?.note === 'string' ? req.body.note.trim() : '';

  if (!Number.isInteger(driverId) || driverId <= 0) {
    res.status(400).json({ error: 'تکایە شۆفێرێک هەڵبژێرە.' });
    return;
  }

  const driver = db.prepare("SELECT * FROM accounts WHERE id = ? AND role = 'driver'").get(driverId) as AccountRow | undefined;
  if (!driver) {
    res.status(404).json({ error: 'شۆفێرە هەڵبژێردراوەکە بوونی نییە.' });
    return;
  }

  if (!Number.isFinite(liters) || liters <= 0) {
    res.status(400).json({ error: 'تکایە بڕی لیتر بە دروستی بنووسە (دەبێت لە ٠ زیاتر بێت).' });
    return;
  }

  if (!Number.isFinite(pricePerLiter) || pricePerLiter < 0 || !Number.isFinite(totalPrice) || totalPrice < 0) {
    res.status(400).json({ error: 'تکایە نرخ بە دروستی بنووسە بە دیناری عێراقی.' });
    return;
  }

  const computedPricePerLiter = pricePerLiter > 0 ? pricePerLiter : liters > 0 ? Math.round(totalPrice / liters) : 0;

  const info = db
    .prepare(
      `INSERT INTO fuel_entries (driver_id, fuel_type, liters, price_per_liter, total_price, entry_date, note, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(driverId, fuelType, liters, computedPricePerLiter, Math.round(totalPrice), entryDate, note, req.user!.id);

  const created = db
    .prepare(
      `SELECT f.*, a.name AS driver_name, a.code AS driver_code, a.truck_plate AS driver_truck_plate
       FROM fuel_entries f
       JOIN accounts a ON a.id = f.driver_id
       WHERE f.id = ?`
    )
    .get(info.lastInsertRowid) as {
      id: number;
      driver_id: number;
      driver_name: string;
      driver_code: string;
      driver_truck_plate: string;
      fuel_type: 'diesel' | 'gas';
      liters: number;
      price_per_liter: number;
      total_price: number;
      entry_date: string;
      note: string;
      created_at: string;
    };

  res.status(201).json({
    entry: {
      id: created.id,
      driverId: created.driver_id,
      driverName: created.driver_name,
      driverCode: created.driver_code,
      driverTruckPlate: created.driver_truck_plate,
      fuelType: created.fuel_type,
      liters: Number(created.liters),
      pricePerLiter: Number(created.price_per_liter),
      totalPrice: Number(created.total_price),
      entryDate: created.entry_date,
      note: created.note,
      createdAt: created.created_at,
    },
  });
});

// Admin: Update fuel entry
app.put('/api/fuel-entries/:id', requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'ناسنامەی تۆمار هەڵەیە.' });
    return;
  }

  const existing = db.prepare('SELECT * FROM fuel_entries WHERE id = ?').get(id) as {
    id: number;
    driver_id: number;
    fuel_type: 'diesel' | 'gas';
    liters: number;
    price_per_liter: number;
    total_price: number;
    entry_date: string;
    note: string;
  } | undefined;

  if (!existing) {
    res.status(404).json({ error: 'تۆمارەکە نەدۆزرایەوە.' });
    return;
  }

  const driverId = req.body?.driverId ? Number(req.body.driverId) : existing.driver_id;
  const fuelType = req.body?.fuelType === 'gas' ? 'gas' : req.body?.fuelType === 'diesel' ? 'diesel' : existing.fuel_type;
  const liters = req.body?.liters !== undefined ? Number(req.body.liters) : existing.liters;
  const pricePerLiter = req.body?.pricePerLiter !== undefined ? Number(req.body.pricePerLiter) : existing.price_per_liter;
  const totalPrice =
    req.body?.totalPrice !== undefined
      ? Number(req.body.totalPrice)
      : Math.round(liters * pricePerLiter);
  const entryDate =
    typeof req.body?.entryDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.entryDate)
      ? req.body.entryDate
      : existing.entry_date;
  const note = typeof req.body?.note === 'string' ? req.body.note.trim() : existing.note;

  if (!Number.isFinite(liters) || liters <= 0 || !Number.isFinite(totalPrice) || totalPrice < 0) {
    res.status(400).json({ error: 'بڕی لیتر یان نرخ هەڵەیە.' });
    return;
  }

  const driver = db.prepare("SELECT id FROM accounts WHERE id = ? AND role = 'driver'").get(driverId);
  if (!driver) {
    res.status(404).json({ error: 'شۆفێرەکە نەدۆزرایەوە.' });
    return;
  }

  db.prepare(
    `UPDATE fuel_entries
     SET driver_id = ?, fuel_type = ?, liters = ?, price_per_liter = ?, total_price = ?, entry_date = ?, note = ?
     WHERE id = ?`
  ).run(driverId, fuelType, liters, pricePerLiter, Math.round(totalPrice), entryDate, note, id);

  res.json({ updated: true });
});

// Admin: Delete fuel entry
app.delete('/api/fuel-entries/:id', requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'ناسنامەی تۆمار هەڵەیە.' });
    return;
  }
  const info = db.prepare('DELETE FROM fuel_entries WHERE id = ?').run(id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'تۆمارەکە نەدۆزرایەوە.' });
    return;
  }
  res.json({ deleted: true });
});

// Admin: Monthly Report
app.get('/api/reports/monthly', requireAuth, requireAdmin, (req, res) => {
  const month = typeof req.query.month === 'string' && /^\d{4}-\d{2}$/.test(req.query.month)
    ? req.query.month
    : getCurrentMonthString();

  const driverRows = db
    .prepare(
      `SELECT
        a.id AS driver_id,
        a.name AS driver_name,
        a.code AS driver_code,
        a.truck_plate AS truck_plate,
        a.phone AS phone,
        COUNT(f.id) AS entry_count,
        COALESCE(SUM(CASE WHEN f.fuel_type = 'diesel' THEN f.liters ELSE 0 END), 0) AS diesel_liters,
        COALESCE(SUM(CASE WHEN f.fuel_type = 'gas' THEN f.liters ELSE 0 END), 0) AS gas_liters,
        COALESCE(SUM(f.liters), 0) AS total_liters,
        COALESCE(SUM(f.total_price), 0) AS total_cost
      FROM accounts a
      JOIN fuel_entries f ON f.driver_id = a.id
      WHERE a.role = 'driver' AND substr(f.entry_date, 1, 7) = ?
      GROUP BY a.id
      ORDER BY total_cost DESC, total_liters DESC, a.name COLLATE NOCASE ASC`
    )
    .all(month) as Array<{
      driver_id: number;
      driver_name: string;
      driver_code: string;
      truck_plate: string;
      phone: string;
      entry_count: number;
      diesel_liters: number;
      gas_liters: number;
      total_liters: number;
      total_cost: number;
    }>;

  const summary = driverRows.reduce(
    (acc, row) => {
      acc.totalLiters += Number(row.total_liters);
      acc.totalCost += Number(row.total_cost);
      acc.dieselLiters += Number(row.diesel_liters);
      acc.gasLiters += Number(row.gas_liters);
      acc.entryCount += Number(row.entry_count);
      acc.driverCount += 1;
      return acc;
    },
    { totalLiters: 0, totalCost: 0, dieselLiters: 0, gasLiters: 0, entryCount: 0, driverCount: 0 }
  );

  const monthRows = db
    .prepare('SELECT DISTINCT substr(entry_date, 1, 7) AS month FROM fuel_entries ORDER BY month DESC')
    .all() as Array<{ month: string }>;

  const availableSet = new Set<string>([getCurrentMonthString(), month, ...monthRows.map((m) => m.month)]);

  res.json({
    month,
    summary,
    drivers: driverRows.map((r) => ({
      driverId: r.driver_id,
      driverName: r.driver_name,
      driverCode: r.driver_code,
      truckPlate: r.truck_plate,
      phone: r.phone,
      entryCount: Number(r.entry_count),
      dieselLiters: Number(r.diesel_liters),
      gasLiters: Number(r.gas_liters),
      totalLiters: Number(r.total_liters),
      totalCost: Number(r.total_cost),
    })),
    availableMonths: Array.from(availableSet).sort((a, b) => b.localeCompare(a)),
  });
});

// Driver Statement (Driver sees own read-only; Admin can pass driverId)
app.get('/api/driver-statement', requireAuth, (req: AuthedRequest, res) => {
  const user = req.user!;
  const targetDriverId = user.role === 'admin' && req.query.driverId ? Number(req.query.driverId) : user.id;

  if (!Number.isInteger(targetDriverId) || targetDriverId <= 0) {
    res.status(400).json({ error: 'ناسنامەی شۆفێر هەڵەیە.' });
    return;
  }

  const driver = db.prepare('SELECT * FROM accounts WHERE id = ?').get(targetDriverId) as AccountRow | undefined;
  if (!driver) {
    res.status(404).json({ error: 'هەژمارەکە نەدۆزرایەوە.' });
    return;
  }

  const rawMonth = typeof req.query.month === 'string' ? req.query.month.trim() : getCurrentMonthString();
  const month = rawMonth === 'all' || /^\d{4}-\d{2}$/.test(rawMonth) ? rawMonth : getCurrentMonthString();

  const entries = (
    month === 'all'
      ? db
          .prepare(
            `SELECT f.*, a.name AS driver_name, a.code AS driver_code, a.truck_plate AS driver_truck_plate
             FROM fuel_entries f
             JOIN accounts a ON a.id = f.driver_id
             WHERE f.driver_id = ?
             ORDER BY f.entry_date DESC, f.id DESC`
          )
          .all(targetDriverId)
      : db
          .prepare(
            `SELECT f.*, a.name AS driver_name, a.code AS driver_code, a.truck_plate AS driver_truck_plate
             FROM fuel_entries f
             JOIN accounts a ON a.id = f.driver_id
             WHERE f.driver_id = ? AND substr(f.entry_date, 1, 7) = ?
             ORDER BY f.entry_date DESC, f.id DESC`
          )
          .all(targetDriverId, month)
  ) as Array<{
    id: number;
    driver_id: number;
    driver_name: string;
    driver_code: string;
    driver_truck_plate: string;
    fuel_type: 'diesel' | 'gas';
    liters: number;
    price_per_liter: number;
    total_price: number;
    entry_date: string;
    note: string;
    created_at: string;
  }>;

  const summary = entries.reduce(
    (acc, row) => {
      acc.totalLiters += Number(row.liters);
      acc.totalCost += Number(row.total_price);
      if (row.fuel_type === 'diesel') acc.dieselLiters += Number(row.liters);
      else acc.gasLiters += Number(row.liters);
      acc.entryCount += 1;
      return acc;
    },
    { totalLiters: 0, totalCost: 0, dieselLiters: 0, gasLiters: 0, entryCount: 0 }
  );

  const lifetimeRow = db
    .prepare(
      `SELECT COUNT(*) AS entry_count, COALESCE(SUM(liters), 0) AS total_liters, COALESCE(SUM(total_price), 0) AS total_cost
       FROM fuel_entries WHERE driver_id = ?`
    )
    .get(targetDriverId) as { entry_count: number; total_liters: number; total_cost: number };

  const monthRows = db
    .prepare('SELECT DISTINCT substr(entry_date, 1, 7) AS month FROM fuel_entries WHERE driver_id = ? ORDER BY month DESC')
    .all(targetDriverId) as Array<{ month: string }>;

  const availableSet = new Set<string>([getCurrentMonthString(), ...monthRows.map((m) => m.month)]);

  res.json({
    driver: mapAccount(driver),
    month,
    summary,
    lifetime: {
      totalLiters: Number(lifetimeRow.total_liters),
      totalCost: Number(lifetimeRow.total_cost),
      entryCount: Number(lifetimeRow.entry_count),
    },
    entries: entries.map((r) => ({
      id: r.id,
      driverId: r.driver_id,
      driverName: r.driver_name,
      driverCode: r.driver_code,
      driverTruckPlate: r.driver_truck_plate,
      fuelType: r.fuel_type,
      liters: Number(r.liters),
      pricePerLiter: Number(r.price_per_liter),
      totalPrice: Number(r.total_price),
      entryDate: r.entry_date,
      note: r.note,
      createdAt: r.created_at,
    })),
    availableMonths: Array.from(availableSet).sort((a, b) => b.localeCompare(a)),
  });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
